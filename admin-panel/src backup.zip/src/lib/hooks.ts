import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { api } from "./api";

export function useApiQuery<T>(key: string[], fetcher: () => Promise<T>, options?: { enabled?: boolean }) {
  return useQuery<T>({
    queryKey: key,
    queryFn: fetcher,
    retry: 1,
    ...options,
  });
}

// Data hooks
export function useUsers() {
  return useApiQuery(["users"], () => api.getUsers());
}

export function useCities() {
  return useApiQuery(["cities"], () => api.getCities());
}

export function useRides() {
  return useApiQuery(["rides"], () => api.getRides());
}

export function useBookings() {
  return useApiQuery(["bookings"], () => api.getBookings());
}

export function useVehicles() {
  return useApiQuery(["vehicles"], () => api.getVehicles());
}

export function useLanguages() {
  return useApiQuery(["languages"], () => api.getLanguages());
}

export function useAppTranslations() {
  return useApiQuery(["app-translations"], () => api.getAppTranslations());
}

export function useReports() {
  return useApiQuery(["reports"], () => api.getReports());
}

export function useSettings() {
  return useApiQuery(["settings"], () => api.getSettings());
}

export function useProfile() {
  return useApiQuery(["profile"], () => api.getProfile());
}

// Mutation hooks
export function useUpdateUser() {
  const qc = useQueryClient();
  return useMutation({
    mutationFn: ({ id, data }: { id: string; data: any }) => api.updateUser(id, data),
    onSuccess: () => qc.invalidateQueries({ queryKey: ["users"] }),
  });
}

export function useUpdateReport() {
  const qc = useQueryClient();
  return useMutation({
    mutationFn: ({ id, data }: { id: string; data: any }) => api.updateReport(id, data),
    onSuccess: () => qc.invalidateQueries({ queryKey: ["reports"] }),
  });
}

export function useCancelBooking() {
  const qc = useQueryClient();
  return useMutation({
    mutationFn: (id: string) => api.cancelBooking(id),
    onSuccess: () => qc.invalidateQueries({ queryKey: ["bookings"] }),
  });
}
