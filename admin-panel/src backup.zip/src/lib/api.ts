const API_BASE = "https://api.nisu.app";

class ApiClient {
  private token: string | null = null;

  constructor() {
    this.token = localStorage.getItem("nisu_token");
  }

  setToken(token: string | null) {
    this.token = token;
    if (token) {
      localStorage.setItem("nisu_token", token);
    } else {
      localStorage.removeItem("nisu_token");
    }
  }

  getToken() {
    return this.token;
  }

  isAuthenticated() {
    return !!this.token;
  }

  private async request<T>(endpoint: string, options: RequestInit = {}): Promise<T> {
    const headers: Record<string, string> = {
      "Content-Type": "application/json",
      ...(options.headers as Record<string, string>),
    };

    if (this.token) {
      headers["Authorization"] = `Bearer ${this.token}`;
    }

    const res = await fetch(`${API_BASE}${endpoint}`, {
      ...options,
      headers,
    });

    if (res.status === 401) {
      this.setToken(null);
      window.location.href = "/login";
      throw new Error("Unauthorized");
    }

    if (!res.ok) {
      const errorBody = await res.text();
      throw new Error(`API error ${res.status}: ${errorBody}`);
    }

    // Handle empty responses
    const text = await res.text();
    if (!text) return {} as T;
    return JSON.parse(text);
  }

  get<T>(endpoint: string) {
    return this.request<T>(endpoint, { method: "GET" });
  }

  post<T>(endpoint: string, body?: unknown) {
    return this.request<T>(endpoint, {
      method: "POST",
      body: body ? JSON.stringify(body) : undefined,
    });
  }

  put<T>(endpoint: string, body?: unknown) {
    return this.request<T>(endpoint, {
      method: "PUT",
      body: body ? JSON.stringify(body) : undefined,
    });
  }

  patch<T>(endpoint: string, body?: unknown) {
    return this.request<T>(endpoint, {
      method: "PATCH",
      body: body ? JSON.stringify(body) : undefined,
    });
  }

  delete<T>(endpoint: string) {
    return this.request<T>(endpoint, { method: "DELETE" });
  }

  // Auth
  async login(email: string, password: string) {
    const data = await this.post<{ access_token: string; user: any }>("/auth/login", { email, password });
    this.setToken(data.access_token);
    return data;
  }

  logout() {
    this.setToken(null);
  }

  // Users
  getProfile() {
    return this.get<any>("/users/profile");
  }

  updateProfile(data: any) {
    return this.put<any>("/users/profile", data);
  }

  getUsers() {
    return this.get<any[]>("/users");
  }

  // NOTE: Backend only supports PUT /users/profile (self-update).
  // For admin actions (ban, verify), we use PUT /users/profile approach
  // but this only works for the logged-in user. Admin user update
  // requires a backend endpoint like PUT /users/:id or PATCH /users/:id.
  // For now, we attempt PUT /users/:id in case the backend adds it.
  updateUser(id: string, data: any) {
    return this.put<any>(`/users/${id}`, data);
  }

  deleteUser(id: string) {
    return this.delete<any>(`/users/${id}`);
  }

  // Rides
  getRides() {
    return this.get<any[]>("/rides");
  }

  getRide(id: string) {
    return this.get<any>(`/rides/${id}`);
  }

  // Bookings
  getBookings() {
    return this.get<any[]>("/bookings");
  }

  // NOTE: No PUT /bookings/:id endpoint exists. Only POST (create) and DELETE (cancel).
  cancelBooking(id: string) {
    return this.delete<any>(`/bookings/${id}`);
  }

  // Vehicles
  getVehicles() {
    return this.get<any[]>("/vehicles");
  }

  // Cities — under /locations prefix
  getCities() {
    return this.get<any[]>("/locations/cities");
  }

  getCity(id: string) {
    return this.get<any>(`/locations/cities/${id}`);
  }

  createCity(data: any) {
    return this.post<any>("/locations/cities", data);
  }

  deleteCity(id: string) {
    return this.delete<any>(`/locations/cities/${id}`);
  }

  getMeetingPoints(cityId: string) {
    return this.get<any[]>(`/locations/cities/${cityId}/meeting-points`);
  }

  // Languages
  getLanguages() {
    return this.get<any[]>("/languages");
  }

  createLanguage(data: any) {
    return this.post<any>("/languages", data);
  }

  updateLanguage(id: number, data: any) {
    return this.put<any>(`/languages/${id}`, data);
  }

  deleteLanguage(id: number) {
    return this.delete<any>(`/languages/${id}`);
  }

  // Translations (read-only app translations by lang)
  getTranslations(lang?: string) {
    const qs = lang ? `?lang=${lang}` : "";
    return this.get<any>(`/translations${qs}`);
  }

  // App Translations (CRUD for admin)
  getAppTranslations() {
    return this.get<any[]>("/app-translations");
  }

  createTranslation(data: any) {
    return this.post<any>("/app-translations", data);
  }

  updateTranslation(id: number, data: any) {
    return this.put<any>(`/app-translations/${id}`, data);
  }

  deleteTranslation(id: number) {
    return this.delete<any>(`/app-translations/${id}`);
  }

  // Reports
  getReports() {
    return this.get<any[]>("/reports");
  }

  getReport(id: string) {
    return this.get<any>(`/reports/${id}`);
  }

  updateReport(id: string, data: any) {
    return this.put<any>(`/reports/${id}`, data);
  }

  deleteReport(id: string) {
    return this.delete<any>(`/reports/${id}`);
  }

  // Settings — update by key, not id
  getSettings() {
    return this.get<any[]>("/settings");
  }

  getSetting(key: string) {
    return this.get<any>(`/settings/${key}`);
  }

  updateSetting(key: string, data: any) {
    return this.put<any>(`/settings/${key}`, data);
  }

  // Chat — under rides/:id/messages
  getChatMessages(rideId: string) {
    return this.get<any[]>(`/rides/${rideId}/messages`);
  }

  sendChatMessage(rideId: string, content: string) {
    return this.post<any>(`/rides/${rideId}/messages`, { content });
  }

  // Notifications
  sendTestNotification() {
    return this.post<any>("/notifications/test");
  }
}

export const api = new ApiClient();
