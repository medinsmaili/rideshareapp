import { useState } from "react";
import { PageHeader } from "@/components/PageHeader";
import { useCities } from "@/lib/hooks";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Search, Plus, Loader2 } from "lucide-react";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from "@/components/ui/dialog";
import { Label } from "@/components/ui/label";

function extractArray(data: any): any[] {
  if (Array.isArray(data)) return data;
  if (data?.data && Array.isArray(data.data)) return data.data;
  return [];
}

export default function CitiesPage() {
  const { data, isLoading, error } = useCities();
  const [search, setSearch] = useState("");
  const [dialogOpen, setDialogOpen] = useState(false);
  const [newCity, setNewCity] = useState({ name: "" });

  const cities = extractArray(data);
  const filtered = cities.filter((c: any) => c.name.toLowerCase().includes(search.toLowerCase()));

  if (isLoading) return <div className="flex items-center justify-center py-20"><Loader2 className="h-8 w-8 animate-spin text-primary" /></div>;
  if (error) return <div className="text-center py-20"><p className="text-destructive">Failed to load cities</p></div>;

  return (
    <div>
      <PageHeader title="Cities" description={`${cities.length} cities configured`} actions={<Button size="sm" onClick={() => setDialogOpen(true)}><Plus className="h-4 w-4 mr-1" /> Add City</Button>} />
      <div className="bg-card rounded-lg border">
        <div className="p-4 border-b">
          <div className="relative max-w-sm">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
            <Input placeholder="Search cities..." value={search} onChange={e => setSearch(e.target.value)} className="pl-9" />
          </div>
        </div>
        <Table>
          <TableHeader>
            <TableRow>
              <TableHead>ID</TableHead>
              <TableHead>Name</TableHead>
            </TableRow>
          </TableHeader>
          <TableBody>
            {filtered.map((city: any) => (
              <TableRow key={city.id}>
                <TableCell className="font-mono-data text-xs">{city.id}</TableCell>
                <TableCell className="font-medium text-sm">{city.name}</TableCell>
              </TableRow>
            ))}
            {filtered.length === 0 && <TableRow><TableCell colSpan={2} className="text-center text-muted-foreground py-8">No cities found</TableCell></TableRow>}
          </TableBody>
        </Table>
      </div>

      <Dialog open={dialogOpen} onOpenChange={setDialogOpen}>
        <DialogContent>
          <DialogHeader><DialogTitle>Add City</DialogTitle></DialogHeader>
          <div><Label>City Name</Label><Input value={newCity.name} onChange={e => setNewCity({ name: e.target.value })} placeholder="e.g. Prishtina" /></div>
          <DialogFooter><Button onClick={() => setDialogOpen(false)}>Add City</Button></DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}
