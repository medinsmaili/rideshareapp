import { PageHeader } from "@/components/PageHeader";
import { useSettings } from "@/lib/hooks";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Loader2, Save } from "lucide-react";
import { useState, useEffect } from "react";
import { api } from "@/lib/api";
import { toast } from "sonner";
import { useQueryClient } from "@tanstack/react-query";

function extractArray(data: any): any[] {
  if (Array.isArray(data)) return data;
  if (data?.data && Array.isArray(data.data)) return data.data;
  return [];
}

export default function SettingsPage() {
  const { data, isLoading, error } = useSettings();
  const qc = useQueryClient();
  const settings = extractArray(data);
  const [editedValues, setEditedValues] = useState<Record<string, string>>({});

  useEffect(() => {
    const initial: Record<string, string> = {};
    settings.forEach((s: any) => { initial[s.key] = s.value || ""; });
    setEditedValues(initial);
  }, [settings]);

  const saveSetting = async (setting: any) => {
    try {
      await api.updateSetting(setting.key, { value: editedValues[setting.key] });
      qc.invalidateQueries({ queryKey: ["settings"] });
      toast.success(`"${setting.key}" updated`);
    } catch { toast.error("Failed to update setting"); }
  };

  if (isLoading) return <div className="flex items-center justify-center py-20"><Loader2 className="h-8 w-8 animate-spin text-primary" /></div>;
  if (error) return <div className="text-center py-20"><p className="text-destructive">Failed to load settings</p></div>;

  return (
    <div>
      <PageHeader title="Settings" description="Platform configuration" />
      <div className="max-w-2xl space-y-4">
        {settings.length === 0 ? (
          <Card><CardContent className="py-8 text-center text-muted-foreground">No settings configured</CardContent></Card>
        ) : (
          settings.map((setting: any) => (
            <Card key={setting.id || setting.key}>
              <CardHeader className="pb-2">
                <CardTitle className="text-sm font-mono">{setting.key}</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="flex items-center gap-2">
                  <Input
                    value={editedValues[setting.key] ?? setting.value ?? ""}
                    onChange={e => setEditedValues(prev => ({ ...prev, [setting.key]: e.target.value }))}
                    className="flex-1"
                  />
                  <Button size="sm" onClick={() => saveSetting(setting)}>
                    <Save className="h-4 w-4 mr-1" /> Save
                  </Button>
                </div>
              </CardContent>
            </Card>
          ))
        )}
      </div>
    </div>
  );
}
