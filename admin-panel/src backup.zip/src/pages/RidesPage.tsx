import { useState, useEffect } from "react";
import { PageHeader } from "@/components/PageHeader";
import { StatusBadge } from "@/components/StatusBadge";
import { useRides } from "@/lib/hooks";
import { api } from "@/lib/api";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Input } from "@/components/ui/input";
import { Sheet, SheetContent, SheetHeader, SheetTitle } from "@/components/ui/sheet";
import { Button } from "@/components/ui/button";
import { Search, Eye, Loader2, MessageCircle } from "lucide-react";
import { ScrollArea } from "@/components/ui/scroll-area";
import { Separator } from "@/components/ui/separator";

function extractArray(data: any): any[] {
  if (Array.isArray(data)) return data;
  if (data?.data && Array.isArray(data.data)) return data.data;
  return [];
}

function getRideName(ride: any, field: "origin" | "destination") {
  if (field === "origin") return ride.origin_city?.name || ride.originCity?.name || ride.origin_city || "?";
  return ride.destination_city?.name || ride.destinationCity?.name || ride.destination_city || "?";
}

function getDriverName(ride: any) {
  if (ride.driver) return `${ride.driver.first_name} ${ride.driver.last_name}`;
  return ride.driver_name || "—";
}

export default function RidesPage() {
  const { data, isLoading, error } = useRides();
  const [search, setSearch] = useState("");
  const [selected, setSelected] = useState<any | null>(null);
  const [drawerOpen, setDrawerOpen] = useState(false);
  const [chatMessages, setChatMessages] = useState<any[]>([]);
  const [chatLoading, setChatLoading] = useState(false);
  const [chatError, setChatError] = useState<string | null>(null);

  useEffect(() => {
    if (selected?.id && drawerOpen) {
      setChatLoading(true);
      setChatError(null);
      setChatMessages([]);
      api.getChatMessages(selected.id)
        .then((data: any) => {
          const msgs = Array.isArray(data) ? data : data?.messages || data?.data || [];
          setChatMessages(msgs);
        })
        .catch((err: any) => setChatError(err.message || "Failed to load chat"))
        .finally(() => setChatLoading(false));
    }
  }, [selected?.id, drawerOpen]);

  const rides = extractArray(data);

  const filtered = rides.filter(r =>
    `${getRideName(r, "origin")} ${getRideName(r, "destination")} ${getDriverName(r)}`.toLowerCase().includes(search.toLowerCase())
  );

  if (isLoading) return <div className="flex items-center justify-center py-20"><Loader2 className="h-8 w-8 animate-spin text-primary" /></div>;
  if (error) return <div className="text-center py-20"><p className="text-destructive">Failed to load rides</p></div>;

  return (
    <div>
      <PageHeader title="Rides" description={`${rides.length} total rides`} />
      <div className="bg-card rounded-lg border">
        <div className="p-4 border-b">
          <div className="relative max-w-sm">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
            <Input placeholder="Search rides..." value={search} onChange={e => setSearch(e.target.value)} className="pl-9" />
          </div>
        </div>
        <Table>
          <TableHeader>
            <TableRow>
              <TableHead>Route</TableHead>
              <TableHead>Driver</TableHead>
              <TableHead>Departure</TableHead>
              <TableHead>Price</TableHead>
              <TableHead>Seats</TableHead>
              <TableHead>Status</TableHead>
              <TableHead className="text-right">Actions</TableHead>
            </TableRow>
          </TableHeader>
          <TableBody>
            {filtered.map(ride => (
              <TableRow key={ride.id}>
                <TableCell className="font-medium text-sm">{getRideName(ride, "origin")} → {getRideName(ride, "destination")}</TableCell>
                <TableCell className="text-sm">{getDriverName(ride)}</TableCell>
                <TableCell className="font-mono-data text-xs">{new Date(ride.departure_time).toLocaleString()}</TableCell>
                <TableCell className="font-mono-data text-sm">€{ride.price_per_seat}</TableCell>
                <TableCell className="text-sm">{ride.seats_taken ?? 0}/{ride.total_seats ?? ride.seats_available ?? 0}</TableCell>
                <TableCell><StatusBadge status={ride.status} /></TableCell>
                <TableCell className="text-right">
                  <Button variant="ghost" size="icon" className="h-8 w-8" onClick={() => { setSelected(ride); setDrawerOpen(true); }}><Eye className="h-4 w-4" /></Button>
                </TableCell>
              </TableRow>
            ))}
            {filtered.length === 0 && <TableRow><TableCell colSpan={7} className="text-center text-muted-foreground py-8">No rides found</TableCell></TableRow>}
          </TableBody>
        </Table>
      </div>

      <Sheet open={drawerOpen} onOpenChange={setDrawerOpen}>
        <SheetContent className="sm:max-w-lg overflow-auto">
          <SheetHeader><SheetTitle>Ride Details</SheetTitle></SheetHeader>
          {selected && (
            <div className="mt-6 space-y-3 text-sm">
              <div className="grid grid-cols-2 gap-4">
                <div><span className="text-muted-foreground">Origin:</span><p className="mt-0.5 font-medium">{getRideName(selected, "origin")}</p></div>
                <div><span className="text-muted-foreground">Destination:</span><p className="mt-0.5 font-medium">{getRideName(selected, "destination")}</p></div>
                <div><span className="text-muted-foreground">Driver:</span><p className="mt-0.5">{getDriverName(selected)}</p></div>
                <div><span className="text-muted-foreground">Vehicle:</span><p className="mt-0.5">{selected.vehicle ? `${selected.vehicle.brand} ${selected.vehicle.model || ""} (${selected.vehicle.color})` : selected.vehicle_name || '—'}</p></div>
                <div><span className="text-muted-foreground">Price/Seat:</span><p className="mt-0.5 font-mono-data">€{selected.price_per_seat}</p></div>
                {selected.student_price && <div><span className="text-muted-foreground">Student Price:</span><p className="mt-0.5 font-mono-data">€{selected.student_price}</p></div>}
                <div><span className="text-muted-foreground">Seats:</span><p className="mt-0.5">{selected.seats_taken ?? 0}/{selected.total_seats ?? selected.seats_available ?? 0}</p></div>
                <div><span className="text-muted-foreground">Status:</span><div className="mt-0.5"><StatusBadge status={selected.status} /></div></div>
                <div><span className="text-muted-foreground">Departure:</span><p className="mt-0.5 font-mono-data text-xs">{new Date(selected.departure_time).toLocaleString()}</p></div>
                {selected.is_female_only && <div><span className="text-muted-foreground">Female Only:</span><p className="mt-0.5">Yes</p></div>}
                {selected.description && <div className="col-span-2"><span className="text-muted-foreground">Description:</span><p className="mt-0.5">{selected.description}</p></div>}
                {selected.cancellation_reason && <div className="col-span-2"><span className="text-muted-foreground">Cancellation Reason:</span><p className="mt-0.5">{selected.cancellation_reason}</p></div>}
                <div className="col-span-2"><span className="text-muted-foreground">ID:</span><p className="mt-0.5 font-mono-data text-xs break-all">{selected.id}</p></div>
              </div>

              <Separator className="my-4" />

              <div>
                <div className="flex items-center gap-2 mb-3">
                  <MessageCircle className="h-4 w-4 text-muted-foreground" />
                  <span className="font-medium">Chat Messages</span>
                  {!chatLoading && <span className="text-xs text-muted-foreground">({chatMessages.length})</span>}
                </div>

                {chatLoading && (
                  <div className="flex items-center justify-center py-6">
                    <Loader2 className="h-5 w-5 animate-spin text-muted-foreground" />
                  </div>
                )}

                {chatError && (
                  <p className="text-xs text-destructive bg-destructive/10 rounded-md px-3 py-2">{chatError}</p>
                )}

                {!chatLoading && !chatError && chatMessages.length === 0 && (
                  <p className="text-xs text-muted-foreground text-center py-4">No messages in this ride</p>
                )}

                {!chatLoading && chatMessages.length > 0 && (
                  <ScrollArea className="max-h-64">
                    <div className="space-y-2">
                      {chatMessages.map((msg: any, i: number) => (
                        <div key={msg.id || i} className="rounded-md border bg-muted/50 px-3 py-2">
                          <div className="flex items-center justify-between gap-2 mb-1">
                            <span className="text-xs font-medium">
                              {msg.sender?.first_name || msg.user?.first_name || "User"}{" "}
                              {msg.sender?.last_name || msg.user?.last_name || ""}
                            </span>
                            <span className="text-[10px] text-muted-foreground font-mono-data">
                              {msg.created_at ? new Date(msg.created_at).toLocaleString() : ""}
                            </span>
                          </div>
                          <p className="text-xs">{msg.content || msg.message || msg.text || ""}</p>
                        </div>
                      ))}
                    </div>
                  </ScrollArea>
                )}
              </div>
            </div>
          )}
        </SheetContent>
      </Sheet>
    </div>
  );
}
