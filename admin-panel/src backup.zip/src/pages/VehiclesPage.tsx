import { PageHeader } from "@/components/PageHeader";
import { useVehicles } from "@/lib/hooks";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Loader2 } from "lucide-react";

function extractArray(data: any): any[] {
  if (Array.isArray(data)) return data;
  if (data?.data && Array.isArray(data.data)) return data.data;
  return [];
}

export default function VehiclesPage() {
  const { data, isLoading, error } = useVehicles();
  const vehicles = extractArray(data);

  if (isLoading) return <div className="flex items-center justify-center py-20"><Loader2 className="h-8 w-8 animate-spin text-primary" /></div>;
  if (error) return <div className="text-center py-20"><p className="text-destructive">Failed to load vehicles</p></div>;

  return (
    <div>
      <PageHeader title="Vehicles" description={`${vehicles.length} registered vehicles`} />
      <div className="bg-card rounded-lg border">
        <Table>
          <TableHeader>
            <TableRow>
              <TableHead>Brand</TableHead>
              <TableHead>Color</TableHead>
              <TableHead>License Plate</TableHead>
              <TableHead>Owner</TableHead>
              <TableHead>ID</TableHead>
            </TableRow>
          </TableHeader>
          <TableBody>
            {vehicles.map((v: any) => (
              <TableRow key={v.id}>
                <TableCell className="font-medium text-sm">{v.brand} {v.model || ""}</TableCell>
                <TableCell className="text-sm">{v.color}</TableCell>
                <TableCell className="font-mono-data text-sm">{v.license_plate}</TableCell>
                <TableCell className="text-sm">
                  {v.owner ? `${v.owner.first_name} ${v.owner.last_name}` : v.owner_name || "—"}
                </TableCell>
                <TableCell className="font-mono-data text-xs">{String(v.id).slice(0, 8)}…</TableCell>
              </TableRow>
            ))}
            {vehicles.length === 0 && <TableRow><TableCell colSpan={5} className="text-center text-muted-foreground py-8">No vehicles found</TableCell></TableRow>}
          </TableBody>
        </Table>
      </div>
    </div>
  );
}
