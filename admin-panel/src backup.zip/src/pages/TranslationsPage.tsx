import { useState, useMemo } from "react";
import { PageHeader } from "@/components/PageHeader";
import { useLanguages } from "@/lib/hooks";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Badge } from "@/components/ui/badge";
import { Search, Plus, Save, Edit2, Check, X, Loader2 } from "lucide-react";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { api } from "@/lib/api";
import { toast } from "sonner";
import { useQueryClient, useQuery } from "@tanstack/react-query";

function extractArray(data: any): any[] {
  if (Array.isArray(data)) return data;
  if (data?.data && Array.isArray(data.data)) return data.data;
  return [];
}

/**
 * Fetches translations for all languages and merges them into a unified list.
 * The /translations?lang= endpoint returns { key: value } objects per language.
 * We also try /app-translations as a fallback.
 */
function useAllTranslations(languages: any[]) {
  return useQuery({
    queryKey: ["all-translations", languages.map(l => l.code)],
    queryFn: async () => {
      // First try /app-translations (CRUD endpoint)
      try {
        const appTrans = await api.getAppTranslations();
        const arr = Array.isArray(appTrans) ? appTrans : (appTrans as any)?.data || [];
        if (arr.length > 0) return { type: "app-translations" as const, data: arr };
      } catch { /* fallback */ }

      // Fallback: fetch /translations?lang= for each language
      if (languages.length === 0) return { type: "translations" as const, data: [] };

      const allEntries: any[] = [];
      for (const lang of languages) {
        try {
          const result = await api.getTranslations(lang.code);
          // result is likely { key: value, ... } or an array
          if (result && typeof result === "object" && !Array.isArray(result)) {
            Object.entries(result).forEach(([key, value]) => {
              allEntries.push({
                id: `${lang.id}-${key}`,
                language_id: lang.id,
                language_code: lang.code,
                key,
                value: value as string,
              });
            });
          } else if (Array.isArray(result)) {
            result.forEach((item: any) => {
              allEntries.push({ ...item, language_id: lang.id, language_code: lang.code });
            });
          }
        } catch { /* skip */ }
      }
      return { type: "translations" as const, data: allEntries };
    },
    enabled: languages.length > 0,
    retry: 1,
  });
}

export default function TranslationsPage() {
  const { data: langData, isLoading: ll } = useLanguages();
  const qc = useQueryClient();
  const languages = extractArray(langData);

  const { data: transResult, isLoading: tl } = useAllTranslations(languages);

  const [selectedLang, setSelectedLang] = useState<string>("all");
  const [search, setSearch] = useState("");
  const [editingId, setEditingId] = useState<string | number | null>(null);
  const [editValue, setEditValue] = useState("");
  const [addOpen, setAddOpen] = useState(false);
  const [newKey, setNewKey] = useState("");
  const [newValues, setNewValues] = useState<Record<number, string>>({});

  const translations = transResult?.data || [];
  const isAppTranslations = transResult?.type === "app-translations";

  const filtered = useMemo(() => {
    return translations.filter((t: any) => {
      const langMatch = selectedLang === "all" || String(t.language_id) === selectedLang || t.language_code === selectedLang;
      const searchMatch = !search || (t.key || "").toLowerCase().includes(search.toLowerCase()) || (t.value || "").toLowerCase().includes(search.toLowerCase());
      return langMatch && searchMatch;
    });
  }, [translations, selectedLang, search]);

  const uniqueKeys = useMemo(() => [...new Set(translations.map((t: any) => t.key))], [translations]);
  const getLangName = (id: number) => languages.find((l: any) => l.id === id)?.name ?? "Unknown";
  const getLangCode = (id: number | string) => {
    const lang = languages.find((l: any) => l.id === id);
    return lang?.code ?? "??";
  };

  const startEdit = (t: any) => { setEditingId(t.id); setEditValue(t.value || ""); };

  const saveEdit = async (t: any) => {
    if (!isAppTranslations) {
      toast.error("Read-only translations (no app-translations endpoint)");
      setEditingId(null);
      return;
    }
    try {
      await api.updateTranslation(t.id, { value: editValue });
      qc.invalidateQueries({ queryKey: ["all-translations"] });
      toast.success("Translation updated");
    } catch { toast.error("Failed to update"); }
    setEditingId(null);
  };

  const addTranslation = async () => {
    if (!newKey.trim()) return;
    try {
      for (const lang of languages) {
        await api.createTranslation({ language_id: lang.id, key: newKey.trim(), value: newValues[lang.id] || "" });
      }
      qc.invalidateQueries({ queryKey: ["all-translations"] });
      toast.success("Translation key added");
      setNewKey(""); setNewValues({}); setAddOpen(false);
    } catch { toast.error("Failed to add translation"); }
  };

  const isLoading = tl || ll;
  if (isLoading) return <div className="flex items-center justify-center py-20"><Loader2 className="h-8 w-8 animate-spin text-primary" /></div>;

  return (
    <div>
      <PageHeader title="Translations" description={`${uniqueKeys.length} keys · ${translations.length} strings across ${languages.length} languages`} />
      <div className="flex flex-wrap items-center gap-3 mb-4">
        <div className="relative flex-1 min-w-[200px] max-w-sm">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
          <Input placeholder="Search keys or values…" value={search} onChange={e => setSearch(e.target.value)} className="pl-9" />
        </div>
        <Select value={selectedLang} onValueChange={setSelectedLang}>
          <SelectTrigger className="w-[160px]"><SelectValue placeholder="All languages" /></SelectTrigger>
          <SelectContent>
            <SelectItem value="all">All languages</SelectItem>
            {languages.map((l: any) => <SelectItem key={l.id} value={String(l.id)}>{l.name}</SelectItem>)}
          </SelectContent>
        </Select>
        <Dialog open={addOpen} onOpenChange={setAddOpen}>
          <DialogTrigger asChild><Button size="sm"><Plus className="h-4 w-4 mr-1" /> Add Key</Button></DialogTrigger>
          <DialogContent>
            <DialogHeader><DialogTitle>Add Translation Key</DialogTitle></DialogHeader>
            <div className="space-y-4">
              <div><Label>Key</Label><Input placeholder="e.g. common.loading" value={newKey} onChange={e => setNewKey(e.target.value)} /></div>
              {languages.map((lang: any) => (
                <div key={lang.id}>
                  <Label>{lang.name} ({lang.code})</Label>
                  <Textarea placeholder={`Translation in ${lang.name}`} value={newValues[lang.id] || ""} onChange={e => setNewValues(prev => ({ ...prev, [lang.id]: e.target.value }))} rows={2} />
                </div>
              ))}
              <Button onClick={addTranslation} className="w-full"><Save className="h-4 w-4 mr-1" /> Save</Button>
            </div>
          </DialogContent>
        </Dialog>
      </div>

      <div className="bg-card rounded-lg border">
        <Table>
          <TableHeader>
            <TableRow>
              <TableHead>Key</TableHead>
              <TableHead>Language</TableHead>
              <TableHead className="w-[40%]">Value</TableHead>
              <TableHead className="w-[100px]">Actions</TableHead>
            </TableRow>
          </TableHeader>
          <TableBody>
            {filtered.map((t: any) => (
              <TableRow key={t.id}>
                <TableCell className="font-mono text-xs text-muted-foreground">{t.key}</TableCell>
                <TableCell><Badge variant="secondary" className="font-mono text-xs">{t.language_code || getLangCode(t.language_id)}</Badge></TableCell>
                <TableCell>
                  {editingId === t.id ? (
                    <div className="flex items-center gap-2">
                      <Input value={editValue} onChange={e => setEditValue(e.target.value)} className="h-8 text-sm" autoFocus />
                      <Button size="icon" variant="ghost" className="h-7 w-7" onClick={() => saveEdit(t)}><Check className="h-3.5 w-3.5 text-primary" /></Button>
                      <Button size="icon" variant="ghost" className="h-7 w-7" onClick={() => setEditingId(null)}><X className="h-3.5 w-3.5 text-destructive" /></Button>
                    </div>
                  ) : (
                    <span className="text-sm">{t.value || <span className="text-muted-foreground italic">empty</span>}</span>
                  )}
                </TableCell>
                <TableCell>
                  <Button size="icon" variant="ghost" className="h-7 w-7" onClick={() => startEdit(t)}><Edit2 className="h-3.5 w-3.5" /></Button>
                </TableCell>
              </TableRow>
            ))}
            {filtered.length === 0 && <TableRow><TableCell colSpan={4} className="text-center text-muted-foreground py-8">No translations found</TableCell></TableRow>}
          </TableBody>
        </Table>
      </div>
    </div>
  );
}
