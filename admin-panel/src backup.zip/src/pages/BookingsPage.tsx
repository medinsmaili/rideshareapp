import { PageHeader } from "@/components/PageHeader";
import { StatusBadge } from "@/components/StatusBadge";
import { useBookings, useRides } from "@/lib/hooks";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Loader2 } from "lucide-react";
import { useMemo } from "react";

function extractArray(data: any): any[] {
  if (Array.isArray(data)) return data;
  if (data?.data && Array.isArray(data.data)) return data.data;
  return [];
}

export default function BookingsPage() {
  const { data, isLoading, error } = useBookings();
  const { data: ridesData, isLoading: ridesLoading } = useRides();
  const bookings = extractArray(data);
  const rides = extractArray(ridesData);

  // Build a ride lookup for route info (since booking.ride doesn't include city relations)
  const rideLookup = useMemo(() => {
    const map: Record<string, any> = {};
    rides.forEach((r: any) => { map[r.id] = r; });
    return map;
  }, [rides]);

  const getRoute = (booking: any) => {
    // First check if the full ride with cities is in the rides list
    const fullRide = rideLookup[booking.ride?.id || booking.ride_id];
    if (fullRide) {
      const origin = fullRide.origin_city?.name || "?";
      const dest = fullRide.destination_city?.name || "?";
      return `${origin} → ${dest}`;
    }
    // Fallback to booking's ride object
    const ride = booking.ride;
    if (ride) {
      const origin = ride.origin_city?.name || "?";
      const dest = ride.destination_city?.name || "?";
      if (origin !== "?" || dest !== "?") return `${origin} → ${dest}`;
    }
    return "—";
  };

  if (isLoading || ridesLoading) return <div className="flex items-center justify-center py-20"><Loader2 className="h-8 w-8 animate-spin text-primary" /></div>;
  if (error) return <div className="text-center py-20"><p className="text-destructive">Failed to load bookings</p></div>;

  return (
    <div>
      <PageHeader title="Bookings" description={`${bookings.length} total bookings`} />
      <div className="bg-card rounded-lg border">
        <Table>
          <TableHeader>
            <TableRow>
              <TableHead>Passenger</TableHead>
              <TableHead>Route</TableHead>
              <TableHead>Seats</TableHead>
              <TableHead>Price</TableHead>
              <TableHead>Status</TableHead>
              <TableHead>Booked At</TableHead>
              <TableHead>ID</TableHead>
            </TableRow>
          </TableHeader>
          <TableBody>
            {bookings.map((b: any) => (
              <TableRow key={b.id}>
                <TableCell className="font-medium text-sm">
                  {b.passenger ? `${b.passenger.first_name} ${b.passenger.last_name}` : b.passenger_name || "—"}
                </TableCell>
                <TableCell className="text-sm">{getRoute(b)}</TableCell>
                <TableCell className="text-sm">{b.seats_booked}</TableCell>
                <TableCell className="font-mono-data text-sm">
                  {b.ride?.price_per_seat ? `€${b.ride.price_per_seat}` : "—"}
                </TableCell>
                <TableCell><StatusBadge status={b.status} /></TableCell>
                <TableCell className="font-mono-data text-xs">{new Date(b.created_at).toLocaleString()}</TableCell>
                <TableCell className="font-mono-data text-xs">{String(b.id).slice(0, 8)}…</TableCell>
              </TableRow>
            ))}
            {bookings.length === 0 && <TableRow><TableCell colSpan={7} className="text-center text-muted-foreground py-8">No bookings found</TableCell></TableRow>}
          </TableBody>
        </Table>
      </div>
    </div>
  );
}
