import { useState } from "react";
import { PageHeader } from "@/components/PageHeader";
import { users } from "@/lib/mock-data";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Button } from "@/components/ui/button";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group";
import { Badge } from "@/components/ui/badge";
import { Bell, Send, Clock, Users, User, X } from "lucide-react";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { toast } from "sonner";

interface SentNotification {
  id: string;
  title: string;
  body: string;
  audience: string;
  sent_at: string;
  recipients: number;
}

const mockSent: SentNotification[] = [
  { id: "n1", title: "Welcome to NISU!", body: "Start your journey with us today.", audience: "All Users", sent_at: "2026-02-19T10:00:00", recipients: 5 },
  { id: "n2", title: "New Feature: Rating System", body: "You can now rate your rides and drivers!", audience: "All Users", sent_at: "2026-02-15T14:30:00", recipients: 5 },
  { id: "n3", title: "Verify Your Account", body: "Complete your profile to start driving.", audience: "Specific User", sent_at: "2026-02-10T09:00:00", recipients: 1 },
];

export default function NotificationsPage() {
  const [title, setTitle] = useState("");
  const [body, setBody] = useState("");
  const [audienceType, setAudienceType] = useState("all");
  const [selectedUserId, setSelectedUserId] = useState("");
  const [history, setHistory] = useState(mockSent);
  const [sending, setSending] = useState(false);

  const handleSend = () => {
    if (!title.trim() || !body.trim()) {
      toast.error("Title and body are required");
      return;
    }
    if (audienceType === "specific" && !selectedUserId) {
      toast.error("Please select a user");
      return;
    }

    setSending(true);
    setTimeout(() => {
      const recipientCount = audienceType === "all" ? users.length : audienceType === "drivers" ? users.filter(u => u.is_verified_driver).length : 1;
      const audienceLabel = audienceType === "all" ? "All Users" : audienceType === "drivers" ? "Verified Drivers" : users.find(u => u.id === selectedUserId)?.first_name + " " + users.find(u => u.id === selectedUserId)?.last_name;

      setHistory(prev => [{
        id: `n${Date.now()}`,
        title: title.trim(),
        body: body.trim(),
        audience: audienceLabel || "Unknown",
        sent_at: new Date().toISOString(),
        recipients: recipientCount,
      }, ...prev]);

      setTitle("");
      setBody("");
      setAudienceType("all");
      setSelectedUserId("");
      setSending(false);
      toast.success(`Notification sent to ${recipientCount} recipient${recipientCount > 1 ? "s" : ""}`);
    }, 800);
  };

  return (
    <div>
      <PageHeader title="Push Notifications" description="Send push notifications to app users" />

      <div className="grid grid-cols-1 lg:grid-cols-5 gap-6">
        {/* Compose */}
        <div className="lg:col-span-2">
          <Card>
            <CardHeader>
              <CardTitle className="text-lg flex items-center gap-2">
                <Bell className="h-4 w-4 text-primary" /> Compose Notification
              </CardTitle>
              <CardDescription>Create and send a push notification</CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div>
                <Label>Title</Label>
                <Input placeholder="Notification title" value={title} onChange={e => setTitle(e.target.value)} maxLength={65} />
                <p className="text-xs text-muted-foreground mt-1">{title.length}/65</p>
              </div>

              <div>
                <Label>Body</Label>
                <Textarea placeholder="Notification message…" value={body} onChange={e => setBody(e.target.value)} rows={4} maxLength={240} />
                <p className="text-xs text-muted-foreground mt-1">{body.length}/240</p>
              </div>

              <div>
                <Label className="mb-2 block">Audience</Label>
                <RadioGroup value={audienceType} onValueChange={setAudienceType} className="space-y-2">
                  <div className="flex items-center gap-2">
                    <RadioGroupItem value="all" id="all" />
                    <Label htmlFor="all" className="flex items-center gap-1.5 cursor-pointer font-normal">
                      <Users className="h-3.5 w-3.5" /> All Users ({users.length})
                    </Label>
                  </div>
                  <div className="flex items-center gap-2">
                    <RadioGroupItem value="drivers" id="drivers" />
                    <Label htmlFor="drivers" className="flex items-center gap-1.5 cursor-pointer font-normal">
                      <Users className="h-3.5 w-3.5" /> Verified Drivers ({users.filter(u => u.is_verified_driver).length})
                    </Label>
                  </div>
                  <div className="flex items-center gap-2">
                    <RadioGroupItem value="specific" id="specific" />
                    <Label htmlFor="specific" className="flex items-center gap-1.5 cursor-pointer font-normal">
                      <User className="h-3.5 w-3.5" /> Specific User
                    </Label>
                  </div>
                </RadioGroup>
              </div>

              {audienceType === "specific" && (
                <div>
                  <Label>Select User</Label>
                  <Select value={selectedUserId} onValueChange={setSelectedUserId}>
                    <SelectTrigger>
                      <SelectValue placeholder="Choose a user" />
                    </SelectTrigger>
                    <SelectContent>
                      {users.map(u => (
                        <SelectItem key={u.id} value={u.id}>{u.first_name} {u.last_name} — {u.email}</SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
              )}

              <Button className="w-full" onClick={handleSend} disabled={sending}>
                <Send className="h-4 w-4 mr-2" />
                {sending ? "Sending…" : "Send Notification"}
              </Button>
            </CardContent>
          </Card>
        </div>

        {/* History */}
        <div className="lg:col-span-3">
          <Card>
            <CardHeader>
              <CardTitle className="text-lg flex items-center gap-2">
                <Clock className="h-4 w-4 text-muted-foreground" /> Sent History
              </CardTitle>
              <CardDescription>{history.length} notifications sent</CardDescription>
            </CardHeader>
            <CardContent className="p-0">
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>Title</TableHead>
                    <TableHead>Audience</TableHead>
                    <TableHead>Recipients</TableHead>
                    <TableHead>Sent</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {history.map(n => (
                    <TableRow key={n.id}>
                      <TableCell>
                        <div>
                          <p className="text-sm font-medium">{n.title}</p>
                          <p className="text-xs text-muted-foreground truncate max-w-[200px]">{n.body}</p>
                        </div>
                      </TableCell>
                      <TableCell><Badge variant="secondary" className="text-xs">{n.audience}</Badge></TableCell>
                      <TableCell className="text-sm">{n.recipients}</TableCell>
                      <TableCell className="font-mono text-xs">{new Date(n.sent_at).toLocaleDateString()}</TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  );
}
