import { useState } from "react";
import { PageHeader } from "@/components/PageHeader";
import { useLanguages } from "@/lib/hooks";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Badge } from "@/components/ui/badge";
import { Switch } from "@/components/ui/switch";
import { Loader2 } from "lucide-react";
import { api } from "@/lib/api";
import { toast } from "sonner";
import { useQueryClient } from "@tanstack/react-query";

function extractArray(data: any): any[] {
  if (Array.isArray(data)) return data;
  if (data?.data && Array.isArray(data.data)) return data.data;
  return [];
}

export default function LanguagesPage() {
  const { data, isLoading, error } = useLanguages();
  const qc = useQueryClient();
  const languages = extractArray(data);

  const toggleActive = async (id: number, currentValue: boolean) => {
    try {
      await api.updateLanguage(id, { is_active: !currentValue });
      qc.invalidateQueries({ queryKey: ["languages"] });
      toast.success("Language updated");
    } catch {
      toast.error("Failed to update language");
    }
  };

  if (isLoading) return <div className="flex items-center justify-center py-20"><Loader2 className="h-8 w-8 animate-spin text-primary" /></div>;
  if (error) return <div className="text-center py-20"><p className="text-destructive">Failed to load languages</p></div>;

  return (
    <div>
      <PageHeader title="Languages" description={`${languages.length} languages configured`} />
      <div className="bg-card rounded-lg border">
        <Table>
          <TableHeader>
            <TableRow>
              <TableHead>Language</TableHead>
              <TableHead>Code</TableHead>
              <TableHead>Active</TableHead>
              <TableHead>Created</TableHead>
            </TableRow>
          </TableHeader>
          <TableBody>
            {languages.map((lang: any) => (
              <TableRow key={lang.id}>
                <TableCell className="font-medium text-sm">{lang.name}</TableCell>
                <TableCell><Badge variant="secondary" className="font-mono-data text-xs">{lang.code}</Badge></TableCell>
                <TableCell><Switch checked={lang.is_active} onCheckedChange={() => toggleActive(lang.id, lang.is_active)} /></TableCell>
                <TableCell className="font-mono-data text-xs">{new Date(lang.created_at).toLocaleDateString()}</TableCell>
              </TableRow>
            ))}
          </TableBody>
        </Table>
      </div>
    </div>
  );
}
