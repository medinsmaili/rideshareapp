import { useState } from "react";
import { PageHeader } from "@/components/PageHeader";
import { StatusBadge } from "@/components/StatusBadge";
import { useReports, useUsers, useUpdateReport } from "@/lib/hooks";
import { getUploadUrl } from "@/lib/types";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Check, X, Mail, Phone, ShieldCheck, Calendar, GraduationCap, Star, Loader2, MapPin } from "lucide-react";
import { toast } from "sonner";
import type { User } from "@/lib/types";

function extractArray(data: any): any[] {
  if (Array.isArray(data)) return data;
  if (data?.data && Array.isArray(data.data)) return data.data;
  return [];
}

function getRideRoute(report: any): string {
  const ride = report.ride;
  if (!ride) return "—";
  const origin = ride.origin_city?.name || "?";
  const dest = ride.destination_city?.name || "?";
  if (origin !== "?" || dest !== "?") return `${origin} → ${dest}`;
  // Fallback: show ride ID snippet
  return `Ride ${String(ride.id).slice(0, 8)}…`;
}

export default function ReportsPage() {
  const { data: reportsData, isLoading: rl } = useReports();
  const { data: usersData, isLoading: ul } = useUsers();
  const updateReport = useUpdateReport();
  const [selectedUser, setSelectedUser] = useState<User | null>(null);

  const reports = extractArray(reportsData);
  const users = extractArray(usersData) as User[];

  const updateStatus = (id: string, status: string) => {
    updateReport.mutate(
      { id, data: { status } },
      { onSuccess: () => toast.success(`Report ${status}`) }
    );
  };

  const openUser = (userId: string, reportUser?: any) => {
    if (reportUser) {
      setSelectedUser(reportUser as User);
      return;
    }
    const user = users.find(u => u.id === userId);
    if (user) setSelectedUser(user);
  };

  const getReporterName = (report: any) => {
    const rel = report.reporter;
    if (rel) return `${rel.first_name} ${rel.last_name}`;
    return report.reporter_name || "Unknown";
  };

  const getReportedName = (report: any) => {
    const rel = report.reported_user;
    if (rel) return `${rel.first_name} ${rel.last_name}`;
    return report.reported_user_name || "Unknown";
  };

  const isLoading = rl || ul;
  if (isLoading) return <div className="flex items-center justify-center py-20"><Loader2 className="h-8 w-8 animate-spin text-primary" /></div>;

  return (
    <div>
      <PageHeader title="Reports" description={`${reports.length} total reports`} />
      <div className="bg-card rounded-lg border">
        <Table>
          <TableHeader>
            <TableRow>
              <TableHead>Reason</TableHead>
              <TableHead>Reporter</TableHead>
              <TableHead>Reported User</TableHead>
              <TableHead>Ride</TableHead>
              <TableHead>Status</TableHead>
              <TableHead>Date</TableHead>
              <TableHead className="text-right">Actions</TableHead>
            </TableRow>
          </TableHeader>
          <TableBody>
            {reports.map((r: any) => (
              <TableRow key={r.id}>
                <TableCell className="font-medium text-sm max-w-[200px] truncate">{r.reason}</TableCell>
                <TableCell>
                  <button onClick={() => openUser(r.reporter_id, r.reporter)} className="text-sm text-primary hover:underline underline-offset-2 cursor-pointer font-medium">
                    {getReporterName(r)}
                  </button>
                </TableCell>
                <TableCell>
                  <button onClick={() => openUser(r.reported_user_id, r.reported_user)} className="text-sm text-primary hover:underline underline-offset-2 cursor-pointer font-medium">
                    {getReportedName(r)}
                  </button>
                </TableCell>
                <TableCell>
                  <div className="flex items-center gap-1 text-sm text-muted-foreground">
                    <MapPin className="h-3 w-3 shrink-0" />
                    <span className="truncate max-w-[150px]">{getRideRoute(r)}</span>
                  </div>
                </TableCell>
                <TableCell><StatusBadge status={r.status} /></TableCell>
                <TableCell className="font-mono-data text-xs">{new Date(r.created_at).toLocaleDateString()}</TableCell>
                <TableCell className="text-right">
                  {(r.status === 'pending' || r.status === 'investigating') && (
                    <div className="flex items-center justify-end gap-1">
                      <Button variant="ghost" size="icon" className="h-8 w-8" onClick={() => updateStatus(r.id, 'resolved')} title="Resolve"><Check className="h-4 w-4 text-success" /></Button>
                      <Button variant="ghost" size="icon" className="h-8 w-8" onClick={() => updateStatus(r.id, 'dismissed')} title="Dismiss"><X className="h-4 w-4 text-destructive" /></Button>
                    </div>
                  )}
                </TableCell>
              </TableRow>
            ))}
            {reports.length === 0 && <TableRow><TableCell colSpan={7} className="text-center text-muted-foreground py-8">No reports</TableCell></TableRow>}
          </TableBody>
        </Table>
      </div>

      <Dialog open={!!selectedUser} onOpenChange={open => !open && setSelectedUser(null)}>
        <DialogContent className="max-w-md">
          {selectedUser && (
            <>
              <DialogHeader>
                <DialogTitle className="flex items-center gap-3">
                  {getUploadUrl(selectedUser.profile_picture, "profiles") && <img src={getUploadUrl(selectedUser.profile_picture, "profiles")!} alt="" className="h-10 w-10 rounded-full object-cover" />}
                  {selectedUser.first_name} {selectedUser.last_name}
                </DialogTitle>
              </DialogHeader>
              <div className="space-y-4">
                <div className="flex flex-wrap gap-2">
                  <Badge variant={selectedUser.role === 'admin' ? 'default' : 'secondary'} className="capitalize">{selectedUser.role}</Badge>
                  {selectedUser.driver_verification_status === 'approved' && <Badge variant="outline" className="bg-success/10 text-success border-success/20 gap-1"><ShieldCheck className="h-3 w-3" /> Driver</Badge>}
                  {selectedUser.student_verification_status === 'approved' && <Badge variant="outline" className="bg-success/10 text-success border-success/20 gap-1"><GraduationCap className="h-3 w-3" /> Student</Badge>}
                  <Badge variant={selectedUser.is_banned ? "destructive" : "secondary"}>{selectedUser.is_banned ? "Banned" : "Active"}</Badge>
                </div>
                {selectedUser.average_rating && (
                  <div className="flex items-center gap-1.5"><Star className="h-4 w-4 text-warning fill-warning" /><span className="font-medium">{selectedUser.average_rating}</span><span className="text-sm text-muted-foreground">({selectedUser.rating_count} ratings)</span></div>
                )}
                <div className="grid grid-cols-1 gap-3 text-sm">
                  <div className="flex items-center gap-2"><Mail className="h-4 w-4 text-muted-foreground" /><div><p className="text-xs text-muted-foreground">Email</p><p className="font-medium">{selectedUser.email}</p></div></div>
                  <div className="flex items-center gap-2"><Phone className="h-4 w-4 text-muted-foreground" /><div><p className="text-xs text-muted-foreground">Phone</p><p className="font-medium">{selectedUser.phone_number || "—"}</p></div></div>
                  <div className="flex items-center gap-2"><Calendar className="h-4 w-4 text-muted-foreground" /><div><p className="text-xs text-muted-foreground">Joined</p><p className="font-medium">{new Date(selectedUser.created_at).toLocaleString()}</p></div></div>
                </div>
                <div className="pt-2 border-t"><p className="text-xs text-muted-foreground font-mono break-all">ID: {selectedUser.id}</p></div>
              </div>
            </>
          )}
        </DialogContent>
      </Dialog>
    </div>
  );
}
