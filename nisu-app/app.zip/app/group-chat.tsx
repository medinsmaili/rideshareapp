import React, { useState, useEffect, useRef } from 'react';
import { View, Text, ScrollView, TextInput, TouchableOpacity, KeyboardAvoidingView, Platform, ActivityIndicator, Image, Keyboard } from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { ArrowLeft, Send } from 'lucide-react-native';
import { useRouter, useLocalSearchParams } from 'expo-router';
import { io, Socket } from 'socket.io-client';
import AsyncStorage from '@react-native-async-storage/async-storage';
import client from '../api/client';
import { useAuth } from '../context/AuthContext';
import { useLanguage } from '../context/LanguageContext';

export default function GroupChatScreen() {
  const router = useRouter();
  const { t } = useLanguage();
  const { rideId, title } = useLocalSearchParams();
  const { user, userToken } = useAuth(); 
  const scrollViewRef = useRef<ScrollView>(null);
  const socketRef = useRef<Socket | null>(null);

  const [messages, setMessages] = useState<any[]>([]);
  const [newMessage, setNewMessage] = useState('');
  const [isLoading, setIsLoading] = useState(true);
  const [isConnected, setIsConnected] = useState(false);
  const [lastReadTime, setLastReadTime] = useState<number | null>(null);

  useEffect(() => {
    // ✅ FIXED: Prevent connection if router hasn't populated the ID yet
    if (!rideId || rideId === 'undefined') return;

    let pollInterval: NodeJS.Timeout;
    const initializeChat = async () => {
      try {
        const storageKey = `last_read_ride_${rideId}`;
        const lastRead = await AsyncStorage.getItem(storageKey);
        const currentReadTime = lastRead ? new Date(lastRead).getTime() : Date.now();
        setLastReadTime(currentReadTime);
        const res = await client.get(`/rides/${rideId}/messages`);
        const history = Array.isArray(res.data) ? res.data : [];
        history.sort((a, b) => new Date(a.created_at).getTime() - new Date(b.created_at).getTime());
        setMessages(history);
        await AsyncStorage.setItem(storageKey, new Date().toISOString());
        setTimeout(() => scrollViewRef.current?.scrollToEnd({ animated: false }), 200);
      } catch (e) { console.error(e); } finally { setIsLoading(false); }
    };

    initializeChat();

    pollInterval = setInterval(async () => {
      try {
        const res = await client.get(`/rides/${rideId}/messages`);
        if (Array.isArray(res.data)) {
          setMessages((prev) => {
            const newMsgs = [...prev];
            let hasChanges = false;
            res.data.forEach((incomingMsg) => {
              if (!newMsgs.find(m => m.id === incomingMsg.id)) { newMsgs.push(incomingMsg); hasChanges = true; }
            });
            if (hasChanges) {
              newMsgs.sort((a, b) => new Date(a.created_at).getTime() - new Date(b.created_at).getTime());
              return newMsgs;
            }
            return prev;
          });
        }
      } catch (error) {}
    }, 5000);

    const socket = io('https://api.nisu.app', { 
      transports: ['websocket'], 
      query: { rideId }, 
      auth: { token: userToken } 
    });
    socketRef.current = socket;
    socket.on('connect', () => { setIsConnected(true); socket.emit('joinRoom', rideId); });
    socket.on('disconnect', () => setIsConnected(false));
    socket.on('newMessage', (message: any) => {
      setMessages((prev) => {
        if (prev.some(m => m.id === message.id)) return prev;
        return [...prev, message];
      });
    });

    return () => { socket.disconnect(); if (pollInterval) clearInterval(pollInterval); };
  }, [rideId, userToken]);

  useEffect(() => {
    const showSubscription = Keyboard.addListener('keyboardDidShow', () => {
      scrollViewRef.current?.scrollToEnd({ animated: true });
    });
    return () => showSubscription.remove();
  }, []);

  const handleSendMessage = async () => {
    if (!newMessage.trim() || !user) return;
    const text = newMessage.trim();
    setNewMessage('');
    try {
      const res = await client.post(`/rides/${rideId}/messages`, { content: text });
      setMessages((prev) => [...prev, res.data]);
    } catch (error) { console.error('Failed to send message', error); }
  };

  const getAvatarUrl = (path?: string, name: string = 'User') => {
    if (!path) return `https://ui-avatars.com/api/?name=${name}&background=14b8a6&color=fff`;
    return path.startsWith('http') ? path : `https://api.nisu.app/${path.startsWith('/') ? path.substring(1) : path}`;
  };

  return (
    <SafeAreaView className="flex-1 bg-background" edges={['top']}>
      <View className="px-6 py-4 border-b border-border bg-card flex-row items-center">
        <TouchableOpacity onPress={() => router.back()} className="p-2 -ml-2"><ArrowLeft size={24} className="text-foreground" /></TouchableOpacity>
        <View className="ml-2 flex-1">
          <Text className="text-lg font-bold text-foreground" numberOfLines={1}>{title || t('ride_chat_default', 'Ride Chat')}</Text>
          <View className="flex-row items-center mt-1">
            <View className={`w-2 h-2 rounded-full mr-1 ${isConnected ? 'bg-green-500' : 'bg-amber-500'}`} />
            <Text className="text-xs text-muted-foreground">{isConnected ? t('chat_live_status', 'Live') : t('chat_sync_status', 'Syncing...')}</Text>
          </View>
        </View>
      </View>

      <KeyboardAvoidingView 
        behavior={Platform.OS === 'ios' ? 'padding' : 'height'} 
        style={{ flex: 1 }}
        keyboardVerticalOffset={Platform.OS === 'ios' ? 90 : 0}
      >
        {isLoading ? (<View className="flex-1 justify-center items-center"><ActivityIndicator color="#14b8a6" /></View>) : (
          <ScrollView 
            ref={scrollViewRef} 
            className="flex-1 px-4 pt-4" 
            showsVerticalScrollIndicator={false}
            onContentSizeChange={() => scrollViewRef.current?.scrollToEnd({ animated: true })}
          >
            {messages.map((msg, index) => {
              const isMe = String(msg.sender_id || msg.userId || msg.sender?.id || '').toLowerCase() === String(user?.id || '').toLowerCase();
              const msgTime = new Date(msg.created_at).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
              const rawTime = new Date(msg.created_at).getTime();
              const isNewBoundary = lastReadTime && rawTime > lastReadTime && (!messages[index-1] || new Date(messages[index-1].created_at).getTime() <= lastReadTime) && !isMe;
              
              return (
                <View key={msg.id || index}>
                  {isNewBoundary && (<View className="flex-row items-center my-6"><View className="flex-1 h-[1px] bg-primary/30" /><Text className="mx-4 text-xs font-bold text-primary uppercase">{t('new_messages_divider', 'New Messages')}</Text><View className="flex-1 h-[1px] bg-primary/30" /></View>)}
                  <View className={`flex-row mb-4 ${isMe ? 'justify-end' : 'justify-start'}`}>
                    {!isMe && <Image source={{ uri: getAvatarUrl(msg.sender?.profile_picture, msg.sender?.first_name) }} className="w-8 h-8 rounded-full bg-muted mr-2 mt-auto" />}
                    <View className={`max-w-[75%] p-3 rounded-2xl ${isMe ? 'bg-primary rounded-tr-none' : 'bg-muted rounded-tl-none'}`}>
                      {!isMe && <Text className="text-[10px] font-bold text-primary mb-1">{msg.sender?.first_name || 'User'}</Text>}
                      <Text className={isMe ? "text-white text-base" : "text-foreground text-base"}>{msg.content}</Text>
                      <Text className={`text-[9px] mt-1 text-right ${isMe ? 'text-white/70' : 'text-muted-foreground'}`}>{msgTime}</Text>
                    </View>
                  </View>
                </View>
              );
            })}
          </ScrollView>
        )}

        <View className="p-4 bg-card border-t border-border flex-row items-center">
          <TextInput 
            className="flex-1 bg-muted px-4 py-3 rounded-2xl text-foreground" 
            placeholder={t('chat_placeholder', 'Type a message...')} 
            placeholderTextColor="#94a3b8" 
            value={newMessage} 
            onChangeText={setNewMessage} 
            multiline 
          />
          <TouchableOpacity 
            onPress={handleSendMessage} 
            className={`ml-3 w-12 h-12 rounded-full items-center justify-center shadow-sm ${newMessage.trim() ? 'bg-primary' : 'bg-muted'}`} 
            disabled={!newMessage.trim()}
          >
            <Send size={20} color="white" />
          </TouchableOpacity>
        </View>
      </KeyboardAvoidingView>
    </SafeAreaView>
  );
}