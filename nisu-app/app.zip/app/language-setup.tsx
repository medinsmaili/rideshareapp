import React from 'react';
import { View, Text, TouchableOpacity, ActivityIndicator, Image } from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { Globe, ChevronRight } from 'lucide-react-native';
import { useLanguage } from '../context/LanguageContext';

export default function LanguageSetupScreen() {
  const { languages, setLanguage, isLoading } = useLanguage();

  if (isLoading && languages.length === 0) {
    return (
      <View className="flex-1 bg-background justify-center items-center">
        <ActivityIndicator size="large" color="#14b8a6" />
      </View>
    );
  }

  return (
    <SafeAreaView className="flex-1 bg-background px-8 justify-center">
      <View className="items-center mb-12">
        <View className="w-24 h-24 bg-primary/10 rounded-full items-center justify-center mb-6">
          <Globe size={48} color="#14b8a6" />
        </View>
        <Text className="text-3xl font-bold text-foreground text-center">Choose Language</Text>
        <Text className="text-muted-foreground text-center mt-2">Zgjidhni gjuhën tuaj të preferuar</Text>
      </View>

      <View className="gap-4">
        {languages.map((lang) => (
          <TouchableOpacity
            key={lang.code}
            onPress={() => setLanguage(lang.code)}
            className="flex-row items-center justify-between p-5 bg-card border border-border rounded-3xl shadow-sm"
          >
            <View className="flex-row items-center">
               <View className="w-10 h-10 rounded-full bg-muted items-center justify-center mr-4">
                 <Text className="font-bold text-foreground">{lang.code.toUpperCase()}</Text>
               </View>
               <Text className="text-xl font-semibold text-foreground">{lang.name}</Text>
            </View>
            <ChevronRight size={20} color="#64748b" />
          </TouchableOpacity>
        ))}
      </View>
    </SafeAreaView>
  );
}