import React, { useState } from 'react';
import { View, Text, ScrollView, TextInput, TouchableOpacity, Image, Alert, ActivityIndicator } from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { Star, ArrowLeft, Send } from 'lucide-react-native';
import { LinearGradient } from 'expo-linear-gradient';
import { useRouter, useLocalSearchParams } from 'expo-router';
import client from '../api/client';
import { useLanguage } from '../context/LanguageContext'; // ✅ Added

export default function RatingReviewScreen() {
  const router = useRouter();
  const { t } = useLanguage(); // ✅ Added
  const { driverId, driverName, driverAvatar } = useLocalSearchParams();
  
  const [rating, setRating] = useState(0);
  const [feedback, setFeedback] = useState('');
  const [isSubmitting, setIsSubmitting] = useState(false);

  const getAvatarUrl = (path?: string, firstName: string = 'User') => {
    if (!path) return `https://ui-avatars.com/api/?name=${firstName}&background=14b8a6&color=fff`;
    if (path.startsWith('http')) return path;
    const cleanPath = path.startsWith('/') ? path.substring(1) : path;
    return `${client.defaults.baseURL}/${cleanPath}`;
  };

  const handleSubmit = async () => {
    if (rating === 0) {
      Alert.alert(t('rating_required', 'Rating Required'), t('select_star_prompt', 'Please select a star rating.'));
      return;
    }

    setIsSubmitting(true);
    try {
      await client.post(`/users/${driverId}/rate`, { rating: rating });
      Alert.alert(t('success', 'Success'), t('review_thank_you', 'Thank you for your review!'));
      router.back();
    } catch (error: any) {
      Alert.alert(t('error', 'Error'), error.response?.data?.message || t('rating_submit_error', 'Could not submit rating.'));
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <SafeAreaView className="flex-1 bg-background" edges={['top']}>
      <View className="flex-row items-center px-6 pt-6 pb-4 border-b border-border bg-card">
        <TouchableOpacity onPress={() => router.back()} className="w-10 h-10 bg-muted rounded-full items-center justify-center mr-4">
          <ArrowLeft size={20} className="text-foreground" />
        </TouchableOpacity>
        <Text className="text-xl font-bold text-foreground">{t('rate_driver', 'Rate Driver')}</Text>
      </View>

      <ScrollView contentContainerStyle={{ padding: 24, paddingBottom: 100 }} showsVerticalScrollIndicator={false}>
        <View className="items-center mb-8">
          <Image source={{ uri: getAvatarUrl(driverAvatar) }} className="w-24 h-24 rounded-full bg-muted mb-4" />
          <Text className="text-2xl font-bold text-foreground">{driverName || t('unknown_driver', 'Unknown Driver')}</Text>
          <Text className="text-muted-foreground mt-1">{t('how_was_ride', 'How was your ride?')}</Text>
        </View>

        <View className="flex-row justify-center gap-4 mb-10">
          {[1, 2, 3, 4, 5].map((star) => (
            <TouchableOpacity key={star} onPress={() => setRating(star)} className="p-1">
              <Star size={40} color={rating >= star ? "#f59e0b" : "#e2e8f0"} fill={rating >= star ? "#f59e0b" : "transparent"} />
            </TouchableOpacity>
          ))}
        </View>

        <View className="mb-8">
          <Text className="text-lg font-bold text-foreground mb-3">{t('leave_feedback', 'Leave Feedback (Optional)')}</Text>
          <TextInput
            className="bg-card border border-border rounded-2xl p-4 text-foreground text-base h-32"
            placeholder={t('feedback_placeholder', 'What did you like about the trip?')}
            placeholderTextColor="#94a3b8"
            multiline
            textAlignVertical="top"
            value={feedback}
            onChangeText={setFeedback}
          />
        </View>

        <TouchableOpacity onPress={handleSubmit} disabled={isSubmitting || rating === 0}>
          <LinearGradient colors={['#14b8a6', '#0d9488']} className="rounded-2xl p-4 items-center justify-center h-14 shadow-sm" style={{ opacity: (isSubmitting || rating === 0) ? 0.5 : 1 }}>
            {isSubmitting ? <ActivityIndicator color="#fff" /> : (
              <View className="flex-row items-center">
                <Send size={20} className="text-white mr-2" />
                <Text className="text-white font-bold text-lg">{t('submit_review', 'Submit Review')}</Text>
              </View>
            )}
          </LinearGradient>
        </TouchableOpacity>
        
        <TouchableOpacity onPress={() => router.back()} className="mt-4 py-3 items-center">
          <Text className="text-muted-foreground font-medium">{t('skip_for_now', 'Skip for now')}</Text>
        </TouchableOpacity>
      </ScrollView>
    </SafeAreaView>
  );
}