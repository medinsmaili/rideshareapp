import React, { useEffect } from 'react';
import { View, ActivityIndicator } from 'react-native';
import { useRouter } from 'expo-router';
import { useAuth } from '../context/AuthContext';
import { useLanguage } from '../context/LanguageContext';

export default function Index() {
  const { userToken, isLoading: authLoading } = useAuth();
  const { hasChosenLanguage, isLoading: langLoading } = useLanguage();
  const router = useRouter();

  useEffect(() => {
    if (authLoading || langLoading) return;

    // ✅ Logic Hierarchy: 1. Language -> 2. Auth
    if (!hasChosenLanguage) {
      router.replace('/language-setup');
    } else if (userToken) {
      router.replace('/(tabs)');
    } else {
      router.replace('/login');
    }
  }, [userToken, authLoading, hasChosenLanguage, langLoading]);

  return (
    <View style={{ flex: 1, justifyContent: 'center', alignItems: 'center', backgroundColor: '#fff' }}>
      <ActivityIndicator size="large" color="#14b8a6" />
    </View>
  );
}