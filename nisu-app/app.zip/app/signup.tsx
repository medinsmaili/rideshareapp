import React, { useState } from 'react';
import { View, Text, TextInput, TouchableOpacity, KeyboardAvoidingView, Platform, ScrollView, Alert, ActivityIndicator } from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { Mail, Lock, User, Phone, ArrowLeft } from 'lucide-react-native';
import { LinearGradient } from 'expo-linear-gradient';
import { useRouter } from 'expo-router';
import { useAuth } from '../context/AuthContext';
import client, { setClientToken } from '../api/client';
import { useLanguage } from '../context/LanguageContext'; // ✅ Added

export default function SignupScreen() {
  const router = useRouter();
  const { signIn } = useAuth();
  const { t } = useLanguage(); // ✅ Added
  
  const [firstName, setFirstName] = useState('');
  const [lastName, setLastName] = useState('');
  const [email, setEmail] = useState('');
  const [phone, setPhone] = useState('');
  const [password, setPassword] = useState('');
  const [isLoading, setIsLoading] = useState(false);

  const handleSignup = async () => {
    if (!firstName || !lastName || !email || !password) {
      Alert.alert(t('error', 'Error'), t('fill_required_fields', 'Please fill in all required fields.'));
      return;
    }

    setIsLoading(true);
    try {
      const payload = {
        first_name: firstName.trim(),
        last_name: lastName.trim(),
        email: email.trim().toLowerCase(),
        phone_number: phone.trim(),
        password: password
      };

      const res = await client.post('/auth/register', payload);
      
      if (res.data && res.data.access_token) {
        const token = res.data.access_token;
        let userData = res.data.user;

        if (!userData) {
           setClientToken(token); 
           const profileRes = await client.get('/users/profile');
           userData = profileRes.data;
        }

        await signIn(token, userData);

        setTimeout(() => {
          if (userData.is_email_verified === false) {
             router.replace('/verify-email');
          }
        }, 100);

      } else {
        Alert.alert(t('success', 'Success'), t('account_created_login', 'Account created successfully! Please log in.'));
        router.replace('/login');
      }
      
    } catch (error: any) {
      const msg = error.response?.data?.message || t('signup_error', 'Failed to create account. Email may already be in use.');
      Alert.alert(t('signup_failed', 'Signup Failed'), Array.isArray(msg) ? msg[0] : msg);
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <SafeAreaView className="flex-1 bg-background">
      <KeyboardAvoidingView behavior={Platform.OS === "ios" ? "padding" : "height"} className="flex-1">
        <ScrollView contentContainerStyle={{ flexGrow: 1, padding: 24, paddingTop: 40 }}>
          
          <TouchableOpacity onPress={() => router.back()} className="w-10 h-10 bg-card rounded-full items-center justify-center border border-border mb-6">
            <ArrowLeft size={20} className="text-foreground" />
          </TouchableOpacity>

          <View className="mb-8">
            <Text className="text-3xl font-bold text-foreground mb-2">{t('create_account', 'Create Account')}</Text>
            <Text className="text-muted-foreground">{t('signup_subtitle', 'Join Nisu today and start saving on your daily commutes.')}</Text>
          </View>

          <View className="gap-4 mb-8">
            <View className="flex-row gap-4">
              <View className="flex-1 bg-card rounded-2xl border border-border flex-row items-center px-4 py-3">
                <User size={20} className="text-muted-foreground mr-2" />
                <TextInput className="flex-1 text-foreground text-base" placeholder={t('first_name', 'First Name')} placeholderTextColor="#94a3b8" value={firstName} onChangeText={setFirstName} />
              </View>
              <View className="flex-1 bg-card rounded-2xl border border-border flex-row items-center px-4 py-3">
                <TextInput className="flex-1 text-foreground text-base" placeholder={t('last_name', 'Last Name')} placeholderTextColor="#94a3b8" value={lastName} onChangeText={setLastName} />
              </View>
            </View>

            <View className="bg-card rounded-2xl border border-border flex-row items-center px-4 py-3">
              <Mail size={20} className="text-muted-foreground mr-3" />
              <TextInput className="flex-1 text-foreground text-base" placeholder={t('email_placeholder', 'Email Address')} placeholderTextColor="#94a3b8" value={email} onChangeText={setEmail} keyboardType="email-address" autoCapitalize="none" />
            </View>

            <View className="bg-card rounded-2xl border border-border flex-row items-center px-4 py-3">
              <Phone size={20} className="text-muted-foreground mr-3" />
              <TextInput className="flex-1 text-foreground text-base" placeholder={t('phone_placeholder', 'Phone Number (Optional)')} placeholderTextColor="#94a3b8" value={phone} onChangeText={setPhone} keyboardType="phone-pad" />
            </View>

            <View className="bg-card rounded-2xl border border-border flex-row items-center px-4 py-3">
              <Lock size={20} className="text-muted-foreground mr-3" />
              <TextInput className="flex-1 text-foreground text-base" placeholder={t('password_placeholder', 'Password')} placeholderTextColor="#94a3b8" value={password} onChangeText={setPassword} secureTextEntry />
            </View>
          </View>

          <TouchableOpacity onPress={handleSignup} disabled={isLoading}>
            <LinearGradient colors={['#14b8a6', '#0d9488']} className="rounded-2xl p-4 items-center justify-center h-14" style={{ opacity: isLoading ? 0.7 : 1 }}>
              {isLoading ? <ActivityIndicator color="#fff" /> : <Text className="text-white font-bold text-lg">{t('sign_up', 'Sign Up')}</Text>}
            </LinearGradient>
          </TouchableOpacity>

          <Text className="text-center text-muted-foreground text-xs mt-4">{t('signup_terms', 'By signing up, you agree to our Terms of Service and Privacy Policy.')}</Text>

        </ScrollView>
      </KeyboardAvoidingView>
    </SafeAreaView>
  );
}