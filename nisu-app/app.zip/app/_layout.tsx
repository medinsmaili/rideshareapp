import { useEffect } from 'react';
import { Stack } from "expo-router";
import { SafeAreaProvider } from "react-native-safe-area-context";
import { LogLevel, OneSignal } from 'react-native-onesignal';
import { AuthProvider } from "../context/AuthContext";
import { LanguageProvider } from "../context/LanguageContext";
import "../global.css";

// ✅ CRITICAL FIX: Boot OneSignal immediately on file load, completely outside of React.
OneSignal.Debug.setLogLevel(LogLevel.None);
OneSignal.initialize("2fee526b-5ca6-4acb-a771-d3e03cad83a2");

export default function RootLayout() {
  useEffect(() => {
    OneSignal.Notifications.requestPermission(true);
  }, []);

  return (
    <SafeAreaProvider>
      <LanguageProvider>
        <AuthProvider>
          <Stack screenOptions={{ headerShown: false }}>
            <Stack.Screen name="language-setup" options={{ animation: 'fade', headerShown: false }} />
            <Stack.Screen name="index" options={{ animation: 'fade' }} />
            <Stack.Screen name="login" options={{ animation: 'fade' }} />
            <Stack.Screen name="signup" options={{ animation: 'fade' }} />
            <Stack.Screen name="(tabs)" options={{ animation: 'fade' }} />
            <Stack.Screen name="edit-profile" options={{ presentation: 'modal' }} />
            <Stack.Screen name="city-picker" options={{ presentation: 'fullScreenModal' }} />
            <Stack.Screen name="search-results" options={{ animation: 'slide_from_right' }} />
            <Stack.Screen name="verify-email" />
            <Stack.Screen name="ride-detail" />
            <Stack.Screen name="group-chat" />
            <Stack.Screen name="my-vehicles" />
            <Stack.Screen name="verification-upload" />
            <Stack.Screen name="rating-review" />
          </Stack>
        </AuthProvider>
      </LanguageProvider>
    </SafeAreaProvider>
  );
}