import React, { useState, useCallback } from 'react';
import { View, Text, ScrollView, TouchableOpacity, TextInput, ActivityIndicator, Alert } from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { Car, Plus, ArrowLeft, Trash2 } from 'lucide-react-native';
import { LinearGradient } from 'expo-linear-gradient';
import { useRouter, useFocusEffect } from 'expo-router';
import client from '../api/client';
import { useLanguage } from '../context/LanguageContext';

export default function MyVehiclesScreen() {
  const router = useRouter();
  const { t } = useLanguage();
  const [vehicles, setVehicles] = useState<any[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  const [isAdding, setIsAdding] = useState(false);
  const [brand, setBrand] = useState('');
  const [color, setColor] = useState('');
  const [licensePlate, setLicensePlate] = useState('');
  const [isSubmitting, setIsSubmitting] = useState(false);

  const fetchVehicles = async () => {
    try {
      const res = await client.get('/users/profile');
      setVehicles(Array.isArray(res.data?.vehicles) ? res.data.vehicles : []);
    } catch (error) { setVehicles([]); } finally { setIsLoading(false); }
  };

  useFocusEffect(useCallback(() => { fetchVehicles(); }, []));

  const handleAddVehicle = async () => {
    if (!brand || !color || !licensePlate) return Alert.alert(t('error_title', 'Error'), t('fill_fields_error', 'Please fill all fields.'));
    setIsSubmitting(true);
    try {
      await client.post('/vehicles', { brand: brand.trim(), color: color.trim(), license_plate: licensePlate.trim().toUpperCase() });
      Alert.alert(t('success_title', 'Success'), t('vehicle_added_msg', 'Vehicle added to your garage!'));
      setBrand(''); setColor(''); setLicensePlate(''); setIsAdding(false); fetchVehicles(); 
    } catch (error: any) { Alert.alert(t('error_title', 'Error'), error.response?.data?.message || t('add_vehicle_fail', 'Could not add vehicle')); } 
    finally { setIsSubmitting(false); }
  };

  const handleDelete = async (id: string) => {
    Alert.alert(t('delete_title', 'Delete'), t('confirm_remove_vehicle', 'Remove this car?'), [
      { text: t('cancel_btn', 'Cancel'), style: 'cancel' },
      { text: t('delete_btn', 'Delete'), style: 'destructive', onPress: async () => {
          try { await client.delete(`/vehicles/${id}`); fetchVehicles(); } 
          catch (error) { Alert.alert(t('error_title', 'Error'), t('delete_fail_msg', 'Could not delete vehicle')); }
      }}
    ]);
  };

  if (isLoading) return <View className="flex-1 bg-background justify-center items-center"><ActivityIndicator size="large" color="#14b8a6" /></View>;

  return (
    <SafeAreaView className="flex-1 bg-background" edges={['top']}>
      <View className="flex-row items-center px-6 pt-6 pb-4 border-b border-border bg-card">
        <TouchableOpacity onPress={() => router.back()} className="w-10 h-10 bg-muted rounded-full items-center justify-center mr-4"><ArrowLeft size={20} className="text-foreground" /></TouchableOpacity>
        <Text className="text-2xl font-bold text-foreground">{t('garage_header', 'Digital Garage')}</Text>
      </View>
      <ScrollView contentContainerStyle={{ padding: 24, paddingBottom: 60 }} showsVerticalScrollIndicator={false}>
        
        {/* ✅ BUG FIX: The Add button disappears seamlessly once the 4-vehicle limit is reached */}
        {!isAdding && vehicles.length < 4 && (
          <TouchableOpacity onPress={() => setIsAdding(true)} className="flex-row items-center justify-center p-5 rounded-2xl border-2 border-dashed border-primary bg-primary/5 mb-8">
            <Plus size={24} className="text-primary mr-2" />
            <Text className="text-primary font-bold text-lg">{t('add_new_vehicle_btn', 'Add New Vehicle')}</Text>
          </TouchableOpacity>
        )}
        
        {!isAdding && vehicles.length >= 4 && (
          <View className="p-4 bg-muted border border-border rounded-2xl mb-8 items-center">
            <Text className="text-muted-foreground text-center">{t('garage_full_msg', 'Your garage is full. You can register a maximum of 4 vehicles.')}</Text>
          </View>
        )}

        {isAdding && (
          <View className="bg-card rounded-3xl p-6 border border-border mb-8 shadow-sm">
            <Text className="text-xl font-bold text-foreground mb-5">{t('vehicle_details_header', 'Vehicle Details')}</Text>
            <View className="gap-4 mb-6">
              <TextInput className="bg-muted p-4 rounded-2xl text-foreground" placeholder={t('brand_placeholder', 'Brand & Model (e.g., Toyota Prius)')} placeholderTextColor="#94a3b8" value={brand} onChangeText={setBrand} />
              <TextInput className="bg-muted p-4 rounded-2xl text-foreground" placeholder={t('color_placeholder', 'Color')} placeholderTextColor="#94a3b8" value={color} onChangeText={setColor} />
              <TextInput className="bg-muted p-4 rounded-2xl text-foreground" placeholder={t('license_plate_placeholder', 'License Plate')} placeholderTextColor="#94a3b8" value={licensePlate} onChangeText={setLicensePlate} autoCapitalize="characters" />
            </View>
            <View className="flex-row gap-4">
              <TouchableOpacity onPress={() => setIsAdding(false)} className="flex-1 bg-muted p-4 rounded-2xl items-center"><Text className="text-foreground font-bold">{t('cancel_btn', 'Cancel')}</Text></TouchableOpacity>
              <TouchableOpacity onPress={handleAddVehicle} disabled={isSubmitting} className="flex-1 rounded-2xl overflow-hidden shadow-sm">
                <LinearGradient colors={['#14b8a6', '#0d9488']} className="p-4 items-center h-full justify-center">{isSubmitting ? <ActivityIndicator color="#fff" /> : <Text className="text-white font-bold">{t('save_btn', 'Save')}</Text>}</LinearGradient>
              </TouchableOpacity>
            </View>
          </View>
        )}

        <Text className="text-lg font-bold text-foreground mb-4">{t('registered_vehicles_header', 'Registered Vehicles')}</Text>
        {vehicles.length === 0 ? (<View className="items-center justify-center py-12 bg-card rounded-3xl border border-border"><Car size={56} className="text-muted/20 mb-4" /><Text className="text-muted-foreground text-center px-8">{t('garage_empty_text', 'Your garage is empty.')}</Text></View>) : 
          vehicles.map((v) => (
            <View key={v.id || Math.random()} className="flex-row items-center p-5 bg-card rounded-3xl mb-4 border border-border shadow-sm">
              <View className="w-14 h-14 bg-primary/10 rounded-full items-center justify-center mr-4"><Car size={28} className="text-primary" /></View>
              <View className="flex-1"><Text className="text-foreground font-bold text-lg">{v.brand}</Text><Text className="text-muted-foreground font-medium">{v.color} • {v.license_plate}</Text></View>
              <TouchableOpacity onPress={() => handleDelete(v.id)} className="p-3 bg-destructive/10 rounded-full"><Trash2 size={20} className="text-destructive" /></TouchableOpacity>
            </View>
          ))
        }
      </ScrollView>
    </SafeAreaView>
  );
}