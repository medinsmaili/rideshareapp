import React, { useState } from 'react';
import { View, Text, TextInput, TouchableOpacity, Alert, ActivityIndicator } from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { useRouter } from 'expo-router';
import { Mail, ArrowLeft } from 'lucide-react-native';
import client from '../api/client';
import { useLanguage } from '../context/LanguageContext';

export default function VerifyEmailScreen() {
  const [code, setCode] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const router = useRouter();
  const { t } = useLanguage();

  const handleVerify = async () => {
    if (code.length !== 6) return Alert.alert(t('error_title', 'Error'), t('code_length_error', 'Code must be 6 digits.'));
    setIsLoading(true);
    try {
      await client.post('/auth/verify-email', { code }); 
      Alert.alert(t('success_title', 'Success'), t('email_verified_msg', 'Email verified!'));
      router.replace('/(tabs)');
    } catch (e: any) {
      Alert.alert(t('error_title', 'Error'), e.response?.data?.message || t('invalid_code_error', 'Incorrect code. Please try again.'));
    } finally { setIsLoading(false); }
  };

  return (
    <SafeAreaView className="flex-1 bg-background">
      <View className="px-6 py-4 flex-row items-center border-b border-border">
         <TouchableOpacity onPress={() => router.back()} className="p-2 -ml-2"><ArrowLeft size={24} className="text-foreground" /></TouchableOpacity>
      </View>
      <View className="flex-1 p-6 justify-center">
        <View className="items-center mb-8">
            <View className="bg-primary/10 p-6 rounded-full mb-6"><Mail size={48} className="text-primary" /></View>
            <Text className="text-3xl font-bold mb-2 text-foreground">{t('check_email_header', 'Check your Email')}</Text>
            <Text className="text-muted-foreground text-center px-4">{t('code_sent_instructions', 'We sent a 6-digit confirmation code to your email address.')}</Text>
        </View>
        <TextInput className="bg-card p-5 rounded-2xl text-center text-3xl font-bold tracking-[10px] mb-8 border border-border text-foreground" keyboardType="number-pad" maxLength={6} value={code} onChangeText={setCode} autoFocus placeholder="000000" placeholderTextColor="#94a3b8" />
        <TouchableOpacity onPress={handleVerify} disabled={isLoading || code.length !== 6} className={`p-5 rounded-2xl items-center shadow-lg ${code.length === 6 ? 'bg-primary' : 'bg-muted'}`}>
            {isLoading ? <ActivityIndicator color="white" /> : <Text className={`font-bold text-lg ${code.length === 6 ? 'text-white' : 'text-muted-foreground'}`}>{t('verify_email_btn', 'Verify Email')}</Text>}
        </TouchableOpacity>
      </View>
    </SafeAreaView>
  );
}