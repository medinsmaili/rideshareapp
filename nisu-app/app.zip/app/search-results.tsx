import React, { useState, useEffect } from 'react';
import { View, Text, ScrollView, TouchableOpacity, ActivityIndicator, Image, RefreshControl, StyleSheet } from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { ArrowLeft, Filter, Clock, Users, Star, Info } from 'lucide-react-native';
import { useRouter, useLocalSearchParams } from 'expo-router';
import client from '../api/client';
import { useLanguage } from '../context/LanguageContext';

export default function SearchResultsScreen() {
  const router = useRouter();
  const { t } = useLanguage();
  const { originId, originName, destId, destName, date } = useLocalSearchParams();
  
  const [results, setResults] = useState<any[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  const [isRefreshing, setIsRefreshing] = useState(false);

  const fetchResults = async () => {
    try {
      setIsLoading(true);
      const queryParams: any = {};
      
      if (originId && String(originId).trim() !== '' && String(originId) !== 'undefined') {
        queryParams.origin_city_id = originId;
      }
      if (destId && String(destId).trim() !== '' && String(destId) !== 'undefined') {
        queryParams.destination_city_id = destId;
      }
      if (date && String(date).trim() !== '' && String(date) !== 'undefined') {
        queryParams.date = date;
      }

      const res = await client.get('/rides/search', { params: queryParams });
      const allResults = Array.isArray(res.data) ? res.data : [];

      const activeRides = allResults.filter(ride => {
        const isStatusActive = ride.status !== 'completed' && ride.status !== 'cancelled';
        const isFutureRide = new Date(ride.departure_time).getTime() > new Date().getTime();
        return isStatusActive && isFutureRide;
      });

      setResults(activeRides);
    } catch (error: any) {
      console.error('Search request failed:', error?.response?.data || error.message);
      setResults([]);
    } finally {
      setIsLoading(false);
      setIsRefreshing(false);
    }
  };

  useEffect(() => {
    fetchResults();
  }, [originId, destId, date]);

  const getAvatarUrl = (path?: string, firstName: string = 'User') => {
    if (!path) return `https://ui-avatars.com/api/?name=${firstName || 'User'}&background=14b8a6&color=fff`;
    if (path.startsWith('http')) return path;
    const cleanPath = path.startsWith('/') ? path.substring(1) : path;
    return `https://api.nisu.app/${cleanPath}`;
  };

  const safeTimeFormat = (dateStr: string) => {
    try { const d = new Date(dateStr); return isNaN(d.getTime()) ? '--:--' : d.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }); } catch { return '--:--'; }
  };

  return (
    <SafeAreaView className="flex-1 bg-background" edges={['top']}>
      <View className="px-6 pt-4 pb-4 border-b border-border bg-card flex-row items-center shadow-sm">
        <TouchableOpacity onPress={() => router.back()} className="p-2 -ml-2">
          <ArrowLeft size={24} className="text-foreground" />
        </TouchableOpacity>
        <View className="flex-1 px-2">
          {/* ✅ FIXED: Replaced hardcoded 'Any' with t('any') */}
          <Text className="text-lg font-bold text-foreground" numberOfLines={1}>
            {originName || t('any', 'Any')} → {destName || t('any', 'Any')}
          </Text>
          <Text className="text-xs text-muted-foreground">{date}</Text>
        </View>
        <TouchableOpacity className="p-2 bg-muted rounded-full">
          <Filter size={20} className="text-foreground" />
        </TouchableOpacity>
      </View>

      {isLoading ? (
        <View className="flex-1 justify-center items-center">
          <ActivityIndicator size="large" color="#14b8a6" />
          <Text className="mt-4 text-muted-foreground font-medium">{t('searching', 'Finding rides...')}</Text>
        </View>
      ) : results.length === 0 ? (
        <View className="flex-1 justify-center items-center px-10">
          <View className="bg-muted p-6 rounded-full mb-4"><Info size={40} className="text-muted-foreground" /></View>
          <Text className="text-xl font-bold text-foreground text-center">{t('no_rides_found', 'No rides found')}</Text>
          <Text className="text-muted-foreground text-center mt-2 leading-5">
            {t('no_rides_desc', 'There are no active rides available for this search.')}
          </Text>
        </View>
      ) : (
        <ScrollView 
          contentContainerStyle={{ padding: 20 }} 
          showsVerticalScrollIndicator={false}
          refreshControl={<RefreshControl refreshing={isRefreshing} onRefresh={() => { setIsRefreshing(true); fetchResults(); }} />}
        >
          {results.map((ride) => (
            <TouchableOpacity 
              key={ride.id}
              onPress={() => router.push(`/ride-detail?id=${ride.id}`)}
              className="bg-card rounded-3xl p-5 mb-4 border border-border shadow-sm"
            >
              <View className="flex-row justify-between items-start mb-4">
                <View className="flex-1">
                  <View className="flex-row items-center mb-1">
                    <Clock size={16} className="text-primary mr-2" />
                    <Text className="text-lg font-bold text-foreground">
                      {safeTimeFormat(ride.departure_time)}
                    </Text>
                  </View>
                  <Text className="text-sm text-muted-foreground ml-6">
                    {ride.origin_city?.name} → {ride.destination_city?.name}
                  </Text>
                </View>
                <View className="bg-primary/10 px-4 py-2 rounded-2xl">
                  <Text className="text-primary font-extrabold text-base">{ride.price_per_seat}€</Text>
                </View>
              </View>

              <View className="flex-row items-center justify-between border-t border-border pt-4">
                <View className="flex-row items-center">
                  <Image source={{ uri: getAvatarUrl(ride.driver?.profile_picture, ride.driver?.first_name) }} className="w-10 h-10 rounded-full bg-muted mr-3" />
                  <View>
                    <Text className="text-foreground font-bold">{ride.driver?.first_name} {ride.driver?.last_name}</Text>
                    <View className="flex-row items-center">
                      <Star size={12} color="#f59e0b" fill="#f59e0b" />
                      <Text className="text-xs ml-1 text-muted-foreground font-medium">{Number(ride.driver?.average_rating || 5).toFixed(1)}</Text>
                    </View>
                  </View>
                </View>
                
                <View className="flex-row items-center bg-muted/50 px-3 py-1.5 rounded-xl">
                  <Users size={14} className="text-muted-foreground mr-1.5" />
                  <Text className="text-xs font-bold text-foreground">{ride.seats_taken}/{ride.total_seats}</Text>
                </View>
              </View>
            </TouchableOpacity>
          ))}
        </ScrollView>
      )}
    </SafeAreaView>
  );
}