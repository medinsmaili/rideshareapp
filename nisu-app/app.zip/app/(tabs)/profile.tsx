import React, { useState, useCallback } from 'react';
import { View, Text, ScrollView, TouchableOpacity, Image, ActivityIndicator, Alert, Modal, StyleSheet } from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { User, Shield, Car, Settings, ChevronRight, LogOut, Bell, Globe, Check, X } from 'lucide-react-native';
import { useRouter, useFocusEffect } from 'expo-router';
import client from '../../api/client';
import { useAuth } from '../../context/AuthContext';
import { useLanguage } from '../../context/LanguageContext';

export default function ProfileScreen() {
  const router = useRouter();
  const { signOut } = useAuth();
  const { t, locale, setLanguage, languages } = useLanguage();
  
  const [profile, setProfile] = useState<any>(null);
  const [isLoading, setIsLoading] = useState(true);
  const [isLangModalVisible, setIsLangModalVisible] = useState(false);

  useFocusEffect(
    useCallback(() => {
      const fetchProfile = async () => {
        try {
          const res = await client.get('/users/profile');
          setProfile(res.data);
        } catch (error) {
          console.error('Failed to fetch profile', error);
        } finally {
          setIsLoading(false);
        }
      };
      fetchProfile();
    }, [])
  );

  const getAvatarUrl = (path?: string, firstName: string = 'User') => {
    if (!path) return `https://ui-avatars.com/api/?name=${firstName}&background=14b8a6&color=fff`;
    if (path.startsWith('http')) return path;
    const cleanPath = path.startsWith('/') ? path.substring(1) : path;
    return `https://api.nisu.app/${cleanPath}`;
  };

  const handleLogout = async () => {
    Alert.alert(t('logout_confirm_title', 'Log Out'), t('logout_confirm_desc', 'Are you sure you want to sign out?'), [
      { text: t('cancel_btn', 'Cancel'), style: 'cancel' },
      { text: t('logout_btn', 'Log Out'), style: 'destructive', onPress: async () => await signOut() },
    ]);
  };

  const renderMenuItem = (icon: any, title: string, subtitle: string, onPress?: () => void) => (
    <TouchableOpacity 
      onPress={onPress}
      className="flex-row items-center bg-card p-4 rounded-2xl mb-3 border border-border shadow-sm"
    >
      <View className="bg-primary/10 p-3 rounded-full mr-4">{icon}</View>
      <View className="flex-1">
        <Text className="text-foreground font-semibold">{title}</Text>
        <Text className="text-sm text-muted-foreground">{subtitle}</Text>
      </View>
      <ChevronRight className="text-muted-foreground" size={20} />
    </TouchableOpacity>
  );

  if (isLoading) {
    return (
      <SafeAreaView className="flex-1 bg-background justify-center items-center">
        <ActivityIndicator size="large" color="#14b8a6" />
      </SafeAreaView>
    );
  }

  return (
    <SafeAreaView className="flex-1 bg-background" edges={['top']}>
      <ScrollView showsVerticalScrollIndicator={false} contentContainerStyle={{ paddingBottom: 40 }}>
        <View className="px-6 pt-6 pb-8 items-center border-b border-border bg-card">
          <TouchableOpacity className="absolute top-6 right-6 p-2 bg-muted rounded-full" onPress={() => router.push('/edit-profile')}>
            <Settings size={20} className="text-foreground" />
          </TouchableOpacity>
          <View className="relative mb-4">
            <Image source={{ uri: getAvatarUrl(profile?.profile_picture, profile?.first_name) }} className="w-24 h-24 rounded-full bg-muted border-2 border-primary/20" />
            <View className="absolute bottom-0 right-0 bg-primary w-8 h-8 rounded-full items-center justify-center border-2 border-card">
              <User size={16} color="#fff" />
            </View>
          </View>
          <Text className="text-2xl font-bold text-foreground">{profile?.first_name || 'User'} {profile?.last_name || ''}</Text>
          <Text className="text-muted-foreground mt-1">{profile?.email || ''}</Text>
          <View className="flex-row items-center mt-3 bg-primary/10 px-3 py-1.5 rounded-full">
            <Shield size={14} className="text-primary mr-1" />
            <Text className="text-primary text-sm font-medium">
              {profile?.is_verified_driver ? t('verified_driver_badge', 'Verified Driver') : t('standard_member_badge', 'Standard Member')}
            </Text>
          </View>
        </View>

        <View className="px-6 mt-6">
          <Text className="text-lg font-bold text-foreground mb-3">{t('dashboard_section', 'Dashboard')}</Text>
          {renderMenuItem(<Car size={20} className="text-primary" />, t('digital_garage_title', 'Digital Garage'), `${profile?.vehicles?.length || 0} ${t('vehicles_count_text', 'vehicles registered')}`, () => router.push('/my-vehicles'))}
          {renderMenuItem(<Shield size={20} className="text-primary" />, t('verifications_title', 'Verifications'), t('verifications_desc_text', 'Upload Driver or Student ID'), () => router.push('/verification-upload'))}
        </View>

        <View className="px-6 mt-4">
          <Text className="text-lg font-bold text-foreground mb-3">{t('settings_section', 'Settings')}</Text>
          {renderMenuItem(<Bell size={20} className="text-primary" />, t('notifications_title', 'Notifications'), t('notifications_desc_text', 'Manage alerts'))}
          {renderMenuItem(<Globe size={20} className="text-primary" />, t('language_title', 'Language'), `${t('current_lang_prefix', 'Current')}: ${languages.find(l => l.code === locale)?.name || locale.toUpperCase()}`, () => setIsLangModalVisible(true))}
        </View>

        <View className="px-6 mt-6 mb-8">
          <TouchableOpacity onPress={handleLogout} className="bg-destructive/10 rounded-2xl p-4 flex-row items-center justify-center border border-destructive/20">
            <LogOut size={20} className="text-destructive mr-2" />
            <Text className="text-destructive font-semibold text-lg">{t('logout_btn_text', 'Log Out')}</Text>
          </TouchableOpacity>
        </View>
      </ScrollView>

      <Modal animationType="slide" transparent={true} visible={isLangModalVisible} onRequestClose={() => setIsLangModalVisible(false)}>
        <View style={styles.modalOverlay}>
          <View style={styles.modalContent}>
            <View className="flex-row justify-between items-center mb-6">
              <Text className="text-xl font-bold text-foreground">{t('select_language_header', 'Select Language')}</Text>
              <TouchableOpacity onPress={() => setIsLangModalVisible(false)} className="bg-muted p-2 rounded-full"><X size={20} className="text-foreground" /></TouchableOpacity>
            </View>
            {languages.map((lang) => (
              <TouchableOpacity key={lang.code} onPress={async () => { await setLanguage(lang.code); setIsLangModalVisible(false); }} className={`flex-row items-center justify-between p-4 rounded-2xl mb-3 border ${locale === lang.code ? 'border-primary bg-primary/5' : 'border-border bg-card'}`}>
                <View className="flex-row items-center">
                  <View className={`w-10 h-10 rounded-full items-center justify-center mr-4 ${locale === lang.code ? 'bg-primary' : 'bg-muted'}`}><Text className="text-white font-bold">{lang.code.toUpperCase()}</Text></View>
                  <Text className={`text-lg font-semibold ${locale === lang.code ? 'text-primary' : 'text-foreground'}`}>{lang.name}</Text>
                </View>
                {locale === lang.code && <Check size={24} className="text-primary" />}
              </TouchableOpacity>
            ))}
          </View>
        </View>
      </Modal>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  modalOverlay: { flex: 1, backgroundColor: 'rgba(0,0,0,0.5)', justifyContent: 'flex-end' },
  modalContent: { backgroundColor: '#fff', borderTopLeftRadius: 32, borderTopRightRadius: 32, padding: 24, paddingBottom: 40, maxHeight: '60%' },
});