import React, { useState, useCallback } from 'react';
import { View, Text, ScrollView, TextInput, TouchableOpacity, Alert, ActivityIndicator, StyleSheet } from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { MapPin, Calendar, Users, Car, Clock, Plus, Minus, Info, GraduationCap, CircleCheck } from 'lucide-react-native';
import { useRouter, useFocusEffect } from 'expo-router';
import AsyncStorage from '@react-native-async-storage/async-storage';
import { LinearGradient } from 'expo-linear-gradient';
import DateTimePicker from '@react-native-community/datetimepicker';
import client from '../../api/client';
import { useLanguage } from '../../context/LanguageContext';

export default function PostRideScreen() {
  const router = useRouter();
  const { t } = useLanguage();

  const [isLoading, setIsLoading] = useState(false);
  const [vehicles, setVehicles] = useState<any[]>([]);

  const [showDatePicker, setShowDatePicker] = useState(false);
  const [showTimePicker, setShowTimePicker] = useState(false);

  const [origin, setOrigin] = useState({ id: '', name: '' });
  const [destination, setDestination] = useState({ id: '', name: '' });
  const [departureDate, setDepartureDate] = useState(new Date());
  const [departureTime, setDepartureTime] = useState(new Date());
  const [seats, setSeats] = useState(3);
  const [price, setPrice] = useState(5.0);
  const [isStudentPricing, setIsStudentPricing] = useState(false);
  const [studentPrice, setStudentPrice] = useState(3.0);
  const [vehicleId, setVehicleId] = useState('');
  const [femaleOnly, setFemaleOnly] = useState(false);

  const checkSelection = async () => {
    try {
      const originStr = await AsyncStorage.getItem('selected_origin');
      const destStr = await AsyncStorage.getItem('selected_destination');
      if (originStr && originStr !== 'undefined') {
        const city = JSON.parse(originStr);
        setOrigin({ id: city.id, name: city.name });
        await AsyncStorage.removeItem('selected_origin');
      }
      if (destStr && destStr !== 'undefined') {
        const city = JSON.parse(destStr);
        setDestination({ id: city.id, name: city.name });
        await AsyncStorage.removeItem('selected_destination');
      }
    } catch (e) { console.error('Storage parse error:', e); }
  };

  const fetchVehicles = async () => {
    try {
      const res = await client.get('/users/profile');
      const userVehicles = Array.isArray(res.data?.vehicles) ? res.data.vehicles : [];
      setVehicles(userVehicles);
      if (userVehicles.length > 0 && !vehicleId) setVehicleId(userVehicles[0].id);
    } catch (e) { console.error('Failed to load vehicles:', e); }
  };

  useFocusEffect(useCallback(() => {
    checkSelection();
    fetchVehicles();
  }, []));

  const adjustPrice = (setter: any, val: number) => setter((prev: number) => parseFloat(Math.max(0.5, prev + val).toFixed(2)));

  const handlePostRide = async () => {
    if (!origin.id || !destination.id || !vehicleId) {
      Alert.alert(t('error_title', 'Error'), t('fill_all_fields_error', 'Please select cities and a vehicle.'));
      return;
    }

    const finalDateTime = new Date(departureDate);
    finalDateTime.setHours(departureTime.getHours(), departureTime.getMinutes(), 0, 0);

    if (finalDateTime.getTime() < Date.now()) {
      Alert.alert(t('error_title', 'Error'), t('departure_past_error', 'Departure time cannot be in the past.'));
      return;
    }

    setIsLoading(true);
    try {
      await client.post('/rides', {
        origin_city_id: origin.id,
        destination_city_id: destination.id,
        departure_time: finalDateTime.toISOString(),
        available_seats: seats, 
        price_per_seat: price,
        is_student_pricing: isStudentPricing,
        student_price_per_seat: isStudentPricing ? studentPrice : null,
        vehicle_id: vehicleId,
        female_only: femaleOnly
      });
      
      Alert.alert(t('success_title', 'Success'), t('ride_posted_msg', 'Your ride has been posted!'), [
        // ✅ BUG FIX: Absolute path redirection prevents context crash
        { text: t('ok_btn', 'OK'), onPress: () => router.replace('/(tabs)/my-rides') }
      ]);
    } catch (error: any) {
      const errorMsg = error.response?.data?.message;
      Alert.alert(t('error_title', 'Error'), Array.isArray(errorMsg) ? errorMsg[0] : (errorMsg || t('post_ride_fail', 'Failed to post ride')));
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <SafeAreaView className="flex-1 bg-background" edges={['top']}>
      {/* ✅ BUG FIX: Added flexGrow: 1 */}
      <ScrollView contentContainerStyle={{ padding: 24, paddingBottom: 100, flexGrow: 1 }} showsVerticalScrollIndicator={false}>
        <Text className="text-3xl font-bold text-foreground mb-6">{t('post_ride_header', 'Offer a Ride')}</Text>

        <View className="bg-card border border-border rounded-3xl p-4 mb-6 shadow-sm">
          {/* ✅ BUG FIX: Safe string routing */}
          <TouchableOpacity onPress={() => router.push('/city-picker?type=origin')} className="flex-row items-center py-3">
            <View className="bg-primary/10 p-2 rounded-full mr-3"><MapPin size={20} className="text-primary" /></View>
            <View className="flex-1">
              <Text className="text-xs text-muted-foreground uppercase font-bold">{t('origin_label', 'Origin')}</Text>
              <Text className={origin.name ? "text-foreground text-lg font-semibold" : "text-muted-foreground text-lg"}>{origin.name || t('select_city_placeholder', "Select City")}</Text>
            </View>
          </TouchableOpacity>
          <View className="h-[1px] bg-border ml-10 my-1" />
          <TouchableOpacity onPress={() => router.push('/city-picker?type=destination')} className="flex-row items-center py-3">
            <View className="bg-destructive/10 p-2 rounded-full mr-3"><MapPin size={20} className="text-destructive" /></View>
            <View className="flex-1">
              <Text className="text-xs text-muted-foreground uppercase font-bold">{t('destination_label', 'Destination')}</Text>
              <Text className={destination.name ? "text-foreground text-lg font-semibold" : "text-muted-foreground text-lg"}>{destination.name || t('select_city_placeholder', "Select City")}</Text>
            </View>
          </TouchableOpacity>
        </View>

        <View className="flex-row gap-4 mb-6">
          <View className="flex-1">
            <Text className="text-xs font-bold text-muted-foreground mb-2 ml-1 uppercase">{t('date_label', 'Date')}</Text>
            <TouchableOpacity onPress={() => setShowDatePicker(true)} className="bg-card border border-border p-4 rounded-2xl flex-row items-center justify-between shadow-sm">
              <Calendar size={18} className="text-primary" />
              <Text className="text-foreground font-bold">{departureDate.toLocaleDateString()}</Text>
            </TouchableOpacity>
          </View>
          <View className="flex-1">
            <Text className="text-xs font-bold text-muted-foreground mb-2 ml-1 uppercase">{t('time_label', 'Time')}</Text>
            <View className="bg-card border border-border p-3 rounded-2xl flex-row items-center justify-between shadow-sm">
              <TouchableOpacity onPress={() => {const d=new Date(departureTime); d.setMinutes(d.getMinutes()-15); setDepartureTime(d);}}><Minus size={20} className="text-primary" /></TouchableOpacity>
              <TouchableOpacity onPress={() => setShowTimePicker(true)}>
                <Text className="text-foreground font-bold">{departureTime.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}</Text>
              </TouchableOpacity>
              <TouchableOpacity onPress={() => {const d=new Date(departureTime); d.setMinutes(d.getMinutes()+15); setDepartureTime(d);}}><Plus size={20} className="text-primary" /></TouchableOpacity>
            </View>
          </View>
        </View>

        <View className="flex-row gap-4 mb-6">
          <View className="flex-1">
            <Text className="text-xs font-bold text-muted-foreground mb-2 ml-1 uppercase">{t('seats_label', 'Seats')}</Text>
            <View className="bg-card border border-border p-3 rounded-2xl flex-row items-center justify-between shadow-sm">
              <TouchableOpacity onPress={() => setSeats(Math.max(1, seats - 1))} className="bg-muted p-2 rounded-lg"><Minus size={18} className="text-primary" /></TouchableOpacity>
              <Text className="text-foreground font-bold text-lg">{seats}</Text>
              <TouchableOpacity onPress={() => setSeats(seats + 1)} className="bg-muted p-2 rounded-lg"><Plus size={18} className="text-primary" /></TouchableOpacity>
            </View>
          </View>
          <View className="flex-1">
            <Text className="text-xs font-bold text-muted-foreground mb-2 ml-1 uppercase">{t('price_label', 'Price (€)')}</Text>
            <View className="bg-card border border-border p-3 rounded-2xl flex-row items-center justify-between shadow-sm">
              <TouchableOpacity onPress={() => adjustPrice(setPrice, -0.5)} className="bg-muted p-2 rounded-lg"><Minus size={18} className="text-primary" /></TouchableOpacity>
              <Text className="text-foreground font-bold text-lg">{price.toFixed(1)}</Text>
              <TouchableOpacity onPress={() => adjustPrice(setPrice, 0.5)} className="bg-muted p-2 rounded-lg"><Plus size={18} className="text-primary" /></TouchableOpacity>
            </View>
          </View>
        </View>

        <View className="gap-3 mb-6">
          <TouchableOpacity onPress={() => setIsStudentPricing(!isStudentPricing)} className={`flex-row items-center justify-between p-4 rounded-2xl border ${isStudentPricing ? 'bg-primary/5 border-primary' : 'bg-card border-border'}`}>
            <View className="flex-row items-center">
              <GraduationCap size={20} className={isStudentPricing ? "text-primary" : "text-muted-foreground"} />
              <Text className={`ml-3 font-bold ${isStudentPricing ? 'text-primary' : 'text-foreground'}`}>{t('student_pricing_btn', 'Student Pricing')}</Text>
            </View>
            <View className={`w-6 h-6 rounded-full border-2 items-center justify-center ${isStudentPricing ? 'border-primary bg-primary' : 'border-muted-foreground'}`}>
              {isStudentPricing && <View className="w-2 h-2 bg-white rounded-full" />}
            </View>
          </TouchableOpacity>

          {isStudentPricing && (
            <View className="bg-card border border-primary/30 p-4 rounded-2xl flex-row items-center justify-between mb-2">
              <Text className="text-muted-foreground font-medium">{t('discounted_price_text', 'Discounted Price:')}</Text>
              <View className="flex-row items-center gap-4">
                <TouchableOpacity onPress={() => adjustPrice(setStudentPrice, -0.5)}><Minus size={20} className="text-primary" /></TouchableOpacity>
                <Text className="text-foreground font-bold text-xl">€{studentPrice.toFixed(1)}</Text>
                <TouchableOpacity onPress={() => adjustPrice(setStudentPrice, 0.5)}><Plus size={20} className="text-primary" /></TouchableOpacity>
              </View>
            </View>
          )}

          <TouchableOpacity onPress={() => setFemaleOnly(!femaleOnly)} className={`flex-row items-center justify-between p-4 rounded-2xl border ${femaleOnly ? 'bg-pink-500/5 border-pink-500' : 'bg-card border-border'}`}>
            <View className="flex-row items-center">
              <Info size={20} className={femaleOnly ? "text-pink-500" : "text-muted-foreground"} />
              <Text className={`ml-3 font-bold ${femaleOnly ? 'text-pink-600' : 'text-foreground'}`}>{t('female_only_btn', 'Female Only Ride')}</Text>
            </View>
            <View className={`w-10 h-6 rounded-full px-1 justify-center ${femaleOnly ? 'bg-pink-500' : 'bg-muted'}`}>
              <View className={`w-4 h-4 bg-white rounded-full ${femaleOnly ? 'self-end' : 'self-start'}`} />
            </View>
          </TouchableOpacity>
        </View>

        <Text className="text-xs font-bold text-muted-foreground mb-3 ml-1 uppercase">{t('select_vehicle_label', 'Select Vehicle')}</Text>
        <View style={styles.vehicleGrid}>
          {vehicles.map((v) => (
            <TouchableOpacity key={v.id} onPress={() => setVehicleId(v.id)} style={styles.vehicleItem} className={`border-2 p-3 ${vehicleId === v.id ? 'bg-primary/5 border-primary' : 'bg-card border-border'}`}>
              <Car size={20} className={vehicleId === v.id ? "text-primary" : "text-muted-foreground"} />
              <Text className={`font-bold mt-1 ${vehicleId === v.id ? 'text-primary' : 'text-foreground'}`} numberOfLines={1}>{v.model}</Text>
              <Text className="text-[10px] text-muted-foreground uppercase">{v.license_plate}</Text>
              {vehicleId === v.id && <View className="absolute top-2 right-2"><CircleCheck size={14} color="#14b8a6" /></View>}
            </TouchableOpacity>
          ))}
          
          {vehicles.length < 4 && (
             <TouchableOpacity onPress={() => router.push('/my-vehicles')} style={styles.vehicleItem} className="bg-muted border border-dashed border-border items-center justify-center">
               <Plus size={24} className="text-muted-foreground" />
               <Text className="text-muted-foreground text-xs mt-2">{t('add_vehicle_btn', 'Add Vehicle')}</Text>
             </TouchableOpacity>
          )}
        </View>

        <TouchableOpacity className="overflow-hidden rounded-2xl shadow-lg mt-8" onPress={handlePostRide} disabled={isLoading}>
          <LinearGradient colors={['#14b8a6', '#0d9488']} className="p-4 items-center justify-center h-14" style={{ opacity: isLoading ? 0.7 : 1 }}>
            {isLoading ? <ActivityIndicator color="white" /> : <Text className="text-white font-bold text-lg">{t('post_ride_btn', 'Post Ride')}</Text>}
          </LinearGradient>
        </TouchableOpacity>

        {showDatePicker && <DateTimePicker value={departureDate} mode="date" minimumDate={new Date()} onChange={(e, d) => { setShowDatePicker(false); if(d) setDepartureDate(d); }} />}
        {showTimePicker && <DateTimePicker value={departureTime} mode="time" is24Hour={true} onChange={(e, d) => { setShowTimePicker(false); if(d) setDepartureTime(d); }} />}
      </ScrollView>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  vehicleGrid: { flexDirection: 'row', flexWrap: 'wrap', gap: 12 },
  vehicleItem: { width: '48%', borderRadius: 16, padding: 12, minHeight: 80, justifyContent: 'center' }
});