import { Tabs } from 'expo-router';
import { Car, History, Plus, User } from 'lucide-react-native';
import { cssInterop, useColorScheme } from 'nativewind';
import { useLanguage } from '../../context/LanguageContext';

cssInterop(Car, { className: { target: 'style', nativeStyleToProp: { color: true } } });
cssInterop(History, { className: { target: 'style', nativeStyleToProp: { color: true } } });
cssInterop(Plus, { className: { target: 'style', nativeStyleToProp: { color: true } } });
cssInterop(User, { className: { target: 'style', nativeStyleToProp: { color: true } } });

export default function TabsLayout() {
  const { colorScheme } = useColorScheme();
  const isDark = colorScheme === 'dark';
  const { t } = useLanguage();

  return (
    <Tabs
      screenOptions={{
        headerShown: false,
        tabBarStyle: {
          backgroundColor: isDark ? '#0f172a' : '#ffffff',
          borderTopColor: isDark ? '#1e293b' : '#e2e8f0',
        },
        tabBarActiveTintColor: isDark ? '#14b8a6' : '#0d9488',
        tabBarInactiveTintColor: isDark ? '#64748b' : '#94a3b8',
      }}
    >
      <Tabs.Screen
        name="index"
        options={{
          title: t('tab_find_rides', 'Find Rides'),
          tabBarIcon: ({ focused }) => (
            <Car className={focused ? 'text-primary' : 'text-muted-foreground'} size={24} />
          ),
        }}
      />
      <Tabs.Screen
        name="my-rides"
        options={{
          title: t('tab_my_rides', 'My Rides'),
          tabBarIcon: ({ focused }) => (
            <History className={focused ? 'text-primary' : 'text-muted-foreground'} size={24} />
          ),
        }}
      />
      <Tabs.Screen
        name="post-ride"
        options={{
          title: t('tab_post_ride', 'Post Ride'),
          tabBarIcon: ({ focused }) => (
            <Plus className={focused ? 'text-primary' : 'text-muted-foreground'} size={24} />
          ),
        }}
      />
      <Tabs.Screen
        name="profile"
        options={{
          title: t('tab_profile', 'Profile'),
          tabBarIcon: ({ focused }) => (
            <User className={focused ? 'text-primary' : 'text-muted-foreground'} size={24} />
          ),
        }}
      />
    </Tabs>
  );
}