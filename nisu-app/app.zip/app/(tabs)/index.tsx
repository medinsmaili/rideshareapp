import React, { useState, useCallback } from 'react';
import { View, Text, ScrollView, TouchableOpacity, ActivityIndicator, RefreshControl, Image } from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { Search, MapPin, Calendar, ArrowRight, Star } from 'lucide-react-native';
import { useRouter, useFocusEffect } from 'expo-router';
import AsyncStorage from '@react-native-async-storage/async-storage';
import client from '../../api/client';
import { useLanguage } from '../../context/LanguageContext';

export default function HomeScreen() {
  const router = useRouter();
  const { t } = useLanguage();
  
  const [origin, setOrigin] = useState({ id: '', name: '' });
  const [dest, setDest] = useState({ id: '', name: '' });
  const [date, setDate] = useState(new Date());
  const [recentRides, setRecentRides] = useState<any[]>([]);
  const [isLoading, setIsLoading] = useState(true);

  const checkSelection = async () => {
    try {
      const originStr = await AsyncStorage.getItem('selected_homeOrigin');
      const destStr = await AsyncStorage.getItem('selected_homeDest');
      if (originStr) {
        const city = JSON.parse(originStr);
        setOrigin({ id: city.id, name: city.name });
        await AsyncStorage.removeItem('selected_homeOrigin');
      }
      if (destStr) {
        const city = JSON.parse(destStr);
        setDest({ id: city.id, name: city.name });
        await AsyncStorage.removeItem('selected_homeDest');
      }
    } catch (e) { console.error(e); }
  };

  const fetchRides = async () => {
    try { 
      const res = await client.get('/rides/search'); 
      const allRides = Array.isArray(res.data) ? res.data : [];
      const activeRides = allRides.filter(ride => {
        return ride.status !== 'completed' && ride.status !== 'cancelled' && new Date(ride.departure_time).getTime() > new Date().getTime();
      });
      setRecentRides(activeRides); 
    } catch (e) { setRecentRides([]); } 
    finally { setIsLoading(false); }
  };

  useFocusEffect(useCallback(() => { 
    checkSelection();
    fetchRides(); 
  }, []));

  const adjustDate = (days: number) => {
    const newDate = new Date(date);
    newDate.setDate(newDate.getDate() + days);
    if (newDate < new Date(new Date().setHours(0,0,0,0))) return;
    setDate(newDate);
  };

  const getAvatarUrl = (path?: string, firstName: string = 'User') => {
    if (!path) return `https://ui-avatars.com/api/?name=${firstName}&background=14b8a6&color=fff`;
    if (path.startsWith('http')) return path;
    const cleanPath = path.startsWith('/') ? path.substring(1) : path;
    return `https://api.nisu.app/${cleanPath}`;
  };

  const safeTimeFormat = (dateStr: string) => {
    try { 
      const d = new Date(dateStr); 
      return isNaN(d.getTime()) ? '--:--' : d.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }); 
    } catch { return '--:--'; }
  };

  return (
    <SafeAreaView className="flex-1 bg-background" edges={['top']}>
      <ScrollView contentContainerStyle={{ flexGrow: 1 }} refreshControl={<RefreshControl refreshing={isLoading} onRefresh={fetchRides} />}>
        <View className="bg-primary px-6 pt-4 pb-12 rounded-b-[40px] shadow-lg">
          <Text className="text-white text-3xl font-bold mb-6">{t('where_to', 'Where to?')}</Text>
          <View className="bg-card p-4 rounded-3xl shadow-xl border border-border">
            <TouchableOpacity onPress={() => router.push('/city-picker?type=homeOrigin')} className="flex-row items-center p-3 border-b border-border">
              <MapPin size={20} color="#14b8a6" style={{ marginRight: 12 }} />
              <View>
                <Text className="text-[10px] text-muted-foreground uppercase font-bold">{t('departure_label', 'Departure')}</Text>
                <Text className={origin.name ? "text-foreground text-lg font-semibold" : "text-muted-foreground text-lg"}>{origin.name || t('from_placeholder', 'From')}</Text>
              </View>
            </TouchableOpacity>
            <TouchableOpacity onPress={() => router.push('/city-picker?type=homeDest')} className="flex-row items-center p-3 border-b border-border">
              <MapPin size={20} color="#ef4444" style={{ marginRight: 12 }} />
              <View>
                <Text className="text-[10px] text-muted-foreground uppercase font-bold">{t('destination_label', 'Destination')}</Text>
                <Text className={dest.name ? "text-foreground text-lg font-semibold" : "text-muted-foreground text-lg"}>{dest.name || t('to_placeholder', 'To')}</Text>
              </View>
            </TouchableOpacity>
            <View className="flex-row items-center mt-3">
              <View className="flex-1 flex-row items-center justify-between bg-muted border border-border p-2 rounded-2xl mr-3">
                <TouchableOpacity onPress={() => adjustDate(-1)} className="px-3 py-2 bg-card rounded-lg shadow-sm"><Text className="text-primary font-bold">-</Text></TouchableOpacity>
                <View className="flex-row items-center"><Calendar size={18} color="#14b8a6" style={{ marginRight: 8 }} /><Text className="text-foreground font-bold">{date.toISOString().split('T')[0]}</Text></View>
                <TouchableOpacity onPress={() => adjustDate(1)} className="px-3 py-2 bg-card rounded-lg"><Text className="text-primary font-bold">+</Text></TouchableOpacity>
              </View>
              <TouchableOpacity onPress={() => router.push(`/search-results?originId=${origin.id}&originName=${encodeURIComponent(origin.name)}&destId=${dest.id}&destName=${encodeURIComponent(dest.name)}&date=${date.toISOString().split('T')[0]}`)} className="bg-primary h-14 w-14 rounded-2xl items-center justify-center shadow-md">
                <Search size={22} color="white" />
              </TouchableOpacity>
            </View>
          </View>
        </View>

        <View className="px-6 mt-8 mb-10">
          <Text className="text-xl font-bold text-foreground mb-4">{t('recent_active_rides', 'Recent Active Rides')}</Text>
          {isLoading ? <ActivityIndicator color="#14b8a6" className="mt-10" /> : recentRides.length === 0 ? (
            <View className="items-center py-10"><Text className="text-muted-foreground italic">{t('no_active_rides', 'No active rides available.')}</Text></View>
          ) : recentRides.map((ride) => (
            <TouchableOpacity key={ride.id} onPress={() => router.push(`/ride-detail?id=${ride.id}`)} className="bg-card rounded-3xl p-4 mb-4 border border-border shadow-sm flex-row">
              <View className="flex-1">
                <View className="flex-row items-center mb-2">
                  <Text className="font-bold text-lg text-foreground">{ride.origin_city?.name}</Text>
                  <ArrowRight size={16} color="#94a3b8" style={{ marginHorizontal: 8 }} />
                  <Text className="font-bold text-lg text-foreground">{ride.destination_city?.name}</Text>
                </View>
                <Text className="text-muted-foreground text-sm">{safeTimeFormat(ride.departure_time)} • {ride.price_per_seat}€</Text>
              </View>
              <View className="items-center justify-center">
                <Image source={{ uri: getAvatarUrl(ride.driver?.profile_picture, ride.driver?.first_name) }} className="w-12 h-12 rounded-full bg-muted mb-1" />
                <View className="flex-row items-center"><Star size={12} color="#f59e0b" fill="#f59e0b" /><Text className="text-[10px] ml-1 text-muted-foreground">{Number(ride.driver?.average_rating || 5).toFixed(1)}</Text></View>
              </View>
            </TouchableOpacity>
          ))}
        </View>
      </ScrollView>
    </SafeAreaView>
  );
}