import React, { useState, useCallback } from 'react';
import { View, Text, FlatList, TouchableOpacity, ActivityIndicator, Image, RefreshControl } from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { MapPin, Calendar, ChevronRight, Users } from 'lucide-react-native';
import { useRouter, useFocusEffect } from 'expo-router';
import client from '../../api/client';
import { useAuth } from '../../context/AuthContext';
import { useLanguage } from '../../context/LanguageContext';

export default function MyRidesScreen() {
  const [activeTab, setActiveTab] = useState<'current_bookings' | 'past_bookings' | 'driver'>('current_bookings');
  const [rides, setRides] = useState<any[]>([]);
  const [bookings, setBookings] = useState<any[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  const [refreshing, setRefreshing] = useState(false);
  const router = useRouter();
  const { user } = useAuth();
  const { t } = useLanguage();

  const fetchRides = async () => {
    try {
      const resRides = await client.get('/rides/my-rides');
      const fetchedRides = Array.isArray(resRides.data) ? resRides.data : (Array.isArray(resRides.data?.data) ? resRides.data.data : []);
      setRides(fetchedRides);
      
      const resProfile = await client.get('/users/profile');
      const profile = resProfile.data || {};
      const fetchedBookings = Array.isArray(profile.bookings) ? profile.bookings : (Array.isArray(profile.data?.bookings) ? profile.data.bookings : []);
      setBookings(fetchedBookings);
    } catch (error) {
      console.error('Failed to fetch rides', error);
    } finally {
      setIsLoading(false);
      setRefreshing(false);
    }
  };

  useFocusEffect(useCallback(() => { fetchRides(); }, []));

  const onRefresh = () => {
    setRefreshing(true);
    fetchRides();
  };

  const isPast = (ride: any) => {
    if (!ride || !ride.departure_time) return false;
    try {
      const d = new Date(ride.departure_time);
      if (isNaN(d.getTime())) return false;
      return ride.status === 'completed' || ride.status === 'cancelled' || d.getTime() < Date.now();
    } catch {
      return false;
    }
  };

  const formatSafeDate = (dateStr: string) => {
    try {
      const d = new Date(dateStr);
      return isNaN(d.getTime()) ? t('unknown_date', 'Unknown Date') : d.toLocaleDateString();
    } catch {
      return t('unknown_date', 'Unknown Date');
    }
  };

  const formatSafeTime = (dateStr: string) => {
    try {
      const d = new Date(dateStr);
      return isNaN(d.getTime()) ? '--:--' : d.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
    } catch {
      return '--:--';
    }
  };

  const validDrivingRides = rides.filter(r => r && r.id);
  const validBookedRides = bookings.map((b: any) => b.ride).filter((r: any) => r && r.id);

  const currentBookings = validBookedRides.filter(r => !isPast(r));
  currentBookings.sort((a, b) => new Date(a.departure_time).getTime() - new Date(b.departure_time).getTime());

  const pastBookings = validBookedRides.filter(r => isPast(r));
  pastBookings.sort((a, b) => new Date(b.departure_time).getTime() - new Date(a.departure_time).getTime());

  const driverRides = [...validDrivingRides];
  driverRides.sort((a, b) => {
    const aPast = isPast(a);
    const bPast = isPast(b);
    if (aPast === bPast) {
        return new Date(b.departure_time).getTime() - new Date(a.departure_time).getTime();
    }
    return aPast ? 1 : -1;
  });

  const displayData = 
    activeTab === 'current_bookings' ? currentBookings : 
    activeTab === 'past_bookings' ? pastBookings : 
    driverRides;

  const handleRidePress = (id: string) => {
    if (!id) return;
    router.push(`/ride-detail?id=${id}`);
  };

  const handleEmptyAction = () => {
    if (activeTab === 'current_bookings' || activeTab === 'past_bookings') {
      router.push('/');
    } else {
      router.push('/post-ride');
    }
  };

  const renderRideCard = ({ item }: { item: any }) => {
    if (!item) return null;

    const isPastRide = isPast(item);
    const isHistoryTab = activeTab === 'past_bookings';
    const displayDate = formatSafeDate(item.departure_time);
    const displayTime = formatSafeTime(item.departure_time);

    if (isHistoryTab) {
      let statusColor = 'bg-muted';
      let textColor = 'text-muted-foreground';
      let statusText = t('status_past', 'Past');

      if (item.status === 'completed') {
        statusColor = 'bg-emerald-500/10';
        textColor = 'text-emerald-600';
        statusText = t('status_completed', 'Completed');
      } else if (item.status === 'cancelled') {
        statusColor = 'bg-destructive/10';
        textColor = 'text-destructive';
        statusText = t('status_cancelled', 'Cancelled');
      }

      return (
        <View className="bg-card mb-4 rounded-3xl p-5 border border-border shadow-sm mx-6">
          <View className="flex-row items-center justify-between mb-4">
            <View className={`${statusColor} px-3 py-1 rounded-full border border-border`}>
              <Text className={`text-xs font-bold ${textColor}`}>{statusText}</Text>
            </View>
            <Text className="text-xs text-muted-foreground font-bold">{displayDate}</Text>
          </View>
          <View className="flex-row items-center">
            <View className="items-center mr-4">
              <View className="w-3 h-3 rounded-full bg-primary" />
              <View className="w-0.5 h-8 bg-border my-1" />
              <View className="w-3 h-3 rounded-full bg-destructive" />
            </View>
            <View className="flex-1 justify-between h-16">
              <Text className="text-base font-bold text-foreground" numberOfLines={1}>{item.origin_city?.name || 'Origin'}</Text>
              <Text className="text-base font-bold text-foreground" numberOfLines={1}>{item.destination_city?.name || 'Destination'}</Text>
            </View>
          </View>
        </View>
      );
    }

    let statusColor = 'bg-primary';
    let textColor = 'text-white';
    let statusText = t('status_active', 'Active');

    if (isPastRide) {
      if (item.status === 'completed') {
        statusColor = 'bg-emerald-500/10';
        textColor = 'text-emerald-600';
        statusText = t('status_completed', 'Completed');
      } else if (item.status === 'cancelled') {
        statusColor = 'bg-destructive/10';
        textColor = 'text-destructive';
        statusText = t('status_cancelled', 'Cancelled');
      } else {
        statusColor = 'bg-muted';
        textColor = 'text-muted-foreground';
        statusText = t('status_past', 'Past');
      }
    }

    return (
      <TouchableOpacity onPress={() => handleRidePress(item.id)} className={`bg-card mb-4 rounded-3xl p-5 border border-border shadow-sm mx-6 active:opacity-90 ${isPastRide ? 'opacity-80' : ''}`}>
        <View className="flex-row justify-between items-start mb-4">
          <View className="flex-row items-center">
            <View className={`p-2 rounded-xl mr-3 ${isPastRide ? 'bg-muted' : 'bg-primary/10'}`}>
               <Calendar size={18} color={isPastRide ? "#94a3b8" : "#14b8a6"} />
            </View>
            <View>
               <Text className={`font-bold ${isPastRide ? 'text-muted-foreground' : 'text-foreground'}`}>{displayDate}</Text>
               <Text className="text-muted-foreground text-xs">{displayTime}</Text>
            </View>
          </View>
          <View className={`${statusColor} px-3 py-1 rounded-full shadow-sm border ${isPastRide && item.status !== 'active' ? 'border-border' : 'border-transparent'}`}>
            <Text className={`font-bold text-xs ${textColor}`}>{statusText}</Text>
          </View>
        </View>

        <View className="flex-row items-center mb-4 bg-muted/30 p-3 rounded-2xl">
          <View className="items-center mr-3">
            <View className={`w-2.5 h-2.5 rounded-full ${isPastRide ? 'bg-muted-foreground' : 'bg-primary'}`} />
            <View className="w-0.5 h-6 bg-border my-1" />
            <View className={`w-2.5 h-2.5 rounded-full ${isPastRide ? 'bg-muted-foreground' : 'bg-destructive'}`} />
          </View>
          <View className="flex-1 justify-between h-14">
            <Text className="text-sm font-bold text-foreground" numberOfLines={1}>{item.origin_city?.name || 'Origin'}</Text>
            <Text className="text-sm font-bold text-foreground" numberOfLines={1}>{item.destination_city?.name || 'Destination'}</Text>
          </View>
        </View>

        <View className="flex-row items-center justify-between border-t border-border pt-4 mt-2">
          {activeTab === 'driver' ? (
             <View className="flex-row items-center">
               <Users size={16} color="#94a3b8" style={{ marginRight: 8 }} />
               <Text className="text-muted-foreground text-sm font-medium">
                 {item.bookings?.length || 0}/{item.total_seats || item.available_seats || 0} {t('seats_label', 'Seats')}
               </Text>
             </View>
          ) : (
             <View className="flex-row items-center">
               <Image source={{ uri: item.driver?.profile_picture ? `https://api.nisu.app/${item.driver.profile_picture}` : `https://ui-avatars.com/api/?name=${item.driver?.first_name || 'U'}&background=14b8a6&color=fff` }} className="w-6 h-6 rounded-full mr-2" />
               <Text className="text-muted-foreground text-sm font-medium">{item.driver?.first_name || 'Driver'}</Text>
             </View>
          )}
          
          <View className="flex-row items-center">
             <Text className="text-lg font-bold text-foreground mr-1">
               {user?.is_student_verified && item.is_student_pricing ? item.student_price_per_seat : item.price_per_seat}€
             </Text>
             <ChevronRight size={18} color="#94a3b8" />
          </View>
        </View>
      </TouchableOpacity>
    );
  };

  const renderEmpty = () => {
    let title, desc, btnText = null;
    
    if (activeTab === 'current_bookings') {
      title = t('no_bookings_title', 'No Bookings Yet');
      desc = t('no_bookings_desc', 'Looking for a ride? Explore available journeys and book your seat.');
      btnText = t('find_ride_btn', 'Find a Ride');
    } else if (activeTab === 'past_bookings') {
      title = t('no_history_title', 'No Past Rides');
      desc = t('no_history_desc', 'Your previous journeys will appear here.');
      btnText = null;
    } else {
      title = t('no_rides_offered_title', 'No Rides Offered');
      desc = t('no_rides_offered_desc', "You haven't offered any rides yet. Share a journey to start earning!");
      btnText = t('offer_ride_btn', 'Offer a Ride');
    }

    return (
      <View style={{ flex: 1, minHeight: 400, justifyContent: 'center', alignItems: 'center', paddingHorizontal: 32, paddingVertical: 40 }}>
        <View className="w-24 h-24 bg-muted rounded-full items-center justify-center mb-6">
          <MapPin size={40} color="#94a3b8" />
        </View>
        <Text className="text-xl font-bold text-foreground text-center mb-2">{title}</Text>
        <Text className="text-muted-foreground text-center mb-8 leading-5">{desc}</Text>
        {btnText && (
          <TouchableOpacity onPress={handleEmptyAction} className="bg-primary px-8 py-4 rounded-2xl shadow-lg">
            <Text className="text-white font-bold text-base">{btnText}</Text>
          </TouchableOpacity>
        )}
      </View>
    );
  };

  return (
    <SafeAreaView style={{ flex: 1, backgroundColor: 'transparent' }} edges={['top']}>
      <View className="px-6 py-4">
        <Text className="text-3xl font-bold text-foreground">{t('my_rides_title', 'My Rides')}</Text>
        <Text className="text-muted-foreground mt-1">{t('my_rides_subtitle', 'Manage your journeys')}</Text>
      </View>

      <View className="flex-row bg-card p-1 rounded-2xl mx-6 mb-6 shadow-sm border border-border">
        <TouchableOpacity onPress={() => setActiveTab('current_bookings')} className={`flex-1 py-2.5 items-center rounded-xl ${activeTab === 'current_bookings' ? 'bg-primary shadow-sm' : ''}`}>
           <Text className={`font-bold text-xs ${activeTab === 'current_bookings' ? 'text-white' : 'text-muted-foreground'}`} numberOfLines={1}>{t('current_bookings_tab', 'Bookings')}</Text>
        </TouchableOpacity>
        <TouchableOpacity onPress={() => setActiveTab('past_bookings')} className={`flex-1 py-2.5 items-center rounded-xl ${activeTab === 'past_bookings' ? 'bg-primary shadow-sm' : ''}`}>
           <Text className={`font-bold text-xs ${activeTab === 'past_bookings' ? 'text-white' : 'text-muted-foreground'}`} numberOfLines={1}>{t('past_bookings_tab', 'Previous')}</Text>
        </TouchableOpacity>
        <TouchableOpacity onPress={() => setActiveTab('driver')} className={`flex-1 py-2.5 items-center rounded-xl ${activeTab === 'driver' ? 'bg-primary shadow-sm' : ''}`}>
           <Text className={`font-bold text-xs ${activeTab === 'driver' ? 'text-white' : 'text-muted-foreground'}`} numberOfLines={1}>{t('driver_tab', 'Driver')}</Text>
        </TouchableOpacity>
      </View>

      {isLoading ? (
        <View style={{ flex: 1, justifyContent: 'center', alignItems: 'center' }}>
          <ActivityIndicator size="large" color="#14b8a6" />
        </View>
      ) : (
        <FlatList
          style={{ flex: 1 }}
          data={displayData}
          keyExtractor={(item, index) => item?.id ? String(item.id) : String(index)}
          renderItem={renderRideCard}
          contentContainerStyle={displayData.length === 0 ? { flex: 1 } : { paddingBottom: 100, flexGrow: 1 }}
          showsVerticalScrollIndicator={false}
          ListEmptyComponent={renderEmpty}
          refreshControl={<RefreshControl refreshing={refreshing} onRefresh={onRefresh} tintColor="#14b8a6" />}
        />
      )}
    </SafeAreaView>
  );
}