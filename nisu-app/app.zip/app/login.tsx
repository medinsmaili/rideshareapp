import React, { useState } from 'react';
import { View, Text, TextInput, TouchableOpacity, KeyboardAvoidingView, Platform, ScrollView, Alert, ActivityIndicator } from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { Mail, Lock, ArrowRight } from 'lucide-react-native';
import { LinearGradient } from 'expo-linear-gradient';
import { useRouter } from 'expo-router';
import { useAuth } from '../context/AuthContext';
import client, { setClientToken } from '../api/client';
import { useLanguage } from '../context/LanguageContext'; // ✅ Added

export default function LoginScreen() {
  const router = useRouter();
  const { signIn } = useAuth();
  const { t } = useLanguage(); // ✅ Added
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [isLoading, setIsLoading] = useState(false);

  const handleLogin = async () => {
    if (!email || !password) {
      Alert.alert(t('error', 'Error'), t('fill_all_fields', 'Please fill in all fields'));
      return;
    }

    setIsLoading(true);
    try {
      const res = await client.post('/auth/login', { 
        email: email.trim().toLowerCase(), 
        password 
      });
      
      if (res.data && res.data.access_token) {
        const token = res.data.access_token;
        let userData = res.data.user;

        if (!userData) {
           setClientToken(token); 
           const profileRes = await client.get('/users/profile');
           userData = profileRes.data;
        }

        await signIn(token, userData);

        setTimeout(() => {
          if (userData.is_email_verified === false) {
             router.replace('/verify-email');
          }
        }, 100);
      }
    } catch (error: any) {
      const msg = error.response?.data?.message || t('invalid_credentials', 'Invalid email or password');
      Alert.alert(t('login_failed', 'Login Failed'), Array.isArray(msg) ? msg[0] : msg);
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <SafeAreaView className="flex-1 bg-background">
      <KeyboardAvoidingView behavior={Platform.OS === "ios" ? "padding" : "height"} className="flex-1">
        <ScrollView contentContainerStyle={{ flexGrow: 1, justifyContent: 'center', padding: 24 }}>
          
          <View className="items-center mb-10">
            <View className="w-20 h-20 bg-primary/10 rounded-3xl items-center justify-center mb-6">
              <Text className="text-4xl font-bold text-primary">N</Text>
            </View>
            <Text className="text-3xl font-bold text-foreground mb-2">{t('welcome_back', 'Welcome Back')}</Text>
            <Text className="text-muted-foreground text-center">{t('login_subtitle', 'Sign in to find your next ride or share your journey.')}</Text>
          </View>

          <View className="gap-4 mb-6">
            <View className="bg-card rounded-2xl border border-border flex-row items-center px-4 py-3">
              <Mail size={20} className="text-muted-foreground mr-3" />
              <TextInput 
                className="flex-1 text-foreground text-base" 
                placeholder={t('email_placeholder', 'Email Address')} 
                placeholderTextColor="#94a3b8" 
                value={email} 
                onChangeText={setEmail} 
                keyboardType="email-address" 
                autoCapitalize="none" 
              />
            </View>

            <View className="bg-card rounded-2xl border border-border flex-row items-center px-4 py-3">
              <Lock size={20} className="text-muted-foreground mr-3" />
              <TextInput 
                className="flex-1 text-foreground text-base" 
                placeholder={t('password_placeholder', 'Password')} 
                placeholderTextColor="#94a3b8" 
                value={password} 
                onChangeText={setPassword} 
                secureTextEntry 
              />
            </View>

            <TouchableOpacity className="self-end mt-2">
              <Text className="text-primary font-medium">{t('forgot_password', 'Forgot Password?')}</Text>
            </TouchableOpacity>
          </View>

          <TouchableOpacity onPress={handleLogin} disabled={isLoading}>
            <LinearGradient colors={['#14b8a6', '#0d9488']} className="rounded-2xl p-4 flex-row items-center justify-center h-14" style={{ opacity: isLoading ? 0.7 : 1 }}>
              {isLoading ? <ActivityIndicator color="#fff" /> : (
                <>
                  <Text className="text-white font-bold text-lg mr-2">{t('sign_in', 'Sign In')}</Text>
                  <ArrowRight size={20} color="#ffffff" />
                </>
              )}
            </LinearGradient>
          </TouchableOpacity>

          <View className="flex-row justify-center mt-8">
            <Text className="text-muted-foreground">{t('no_account', "Don't have an account? ")}</Text>
            <TouchableOpacity onPress={() => router.push('/signup')}>
              <Text className="text-primary font-bold">{t('sign_up', 'Sign Up')}</Text>
            </TouchableOpacity>
          </View>

        </ScrollView>
      </KeyboardAvoidingView>
    </SafeAreaView>
  );
}